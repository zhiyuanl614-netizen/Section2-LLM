# 第2章 基于大语言模型全文证据挖掘的水-电耦合系统前沿研究方向识别

> v2 说明：本版本将 Step 2 和 Step 3 重新设计为真正调用大语言模型的可审计流程。旧版规则化结果已从当前工作目录清理；仅受保护的 benchmark 历史结果保存在 `/home/user/_protected_benchmark_archive/`。

## 2.1 研究问题与全文证据单元

### 2.1.1 研究问题

- RQ1：现有水-电耦合研究如何表征水-电耦合方向、厂内冷却水和核心耦合方程？
- RQ2：现有研究是否利用信息层快感知与水-热-水力慢演化之间的时间尺度差进行早期预警和主动控制？
- RQ3：级联故障后果是否从物理网络服务损失延伸到人口、关键民生设施、社会脆弱性和 Shelby County 人类影响？
- RQ4：作者在全文结尾明确承认的模型局限和未来方向，是否能支持第 3–5 章的研究空白识别？

### 2.1.2 分析单元

本章不以摘要或关键词作为主要分析单元，而以以下三类全文证据作为基本单元：

1. 文献级单元：一篇论文的完整四区切片；
2. 章节级单元：方法、模型、仿真、案例、讨论和局限性章节；
3. 证据级单元：一个可回溯到 section、page 和原文字符区间的句子、公式、表格说明或算法步骤。

## 2.2 PDF 全文解析与可复现证据语料库

### 2.2.1 Step 1：PDF 版面解析

Step 1 继续使用 PyMuPDF 读取 PDF 文本块、坐标、字体和页码，构建章节树及 Zone A–D 四区切片。Step 1 输出必须为稳定的 evidence-ready 语料格式，而不仅是可读文本：

```json
{
  "evidence_id": "B002-PDF-02-S02-P02-E0007",
  "doc_id": "B002-PDF-02",
  "section_id": "2.2",
  "section_title": "Cascading model",
  "page": 2,
  "zone": "Zone_B",
  "text": "...",
  "char_start": 1820,
  "char_end": 2076
}
```

### 2.2.2 全文证据边界

- Zone A：标题、摘要和 Introduction 末段，仅用于研究对象、贡献和范围识别；
- Zone B：系统架构、问题定义、耦合机制、核心方程和级联模型；
- Zone C：指标、仿真控制、预警、缓解、恢复和优化；
- Zone D：案例、社会/人类影响、讨论、局限和未来研究；
- References、Acknowledgments、作者简介和纯综述段落不作为本文方法证据；
- 如果全文切片缺少公式图像、表格图像或原始版面信息，必须标记 `evidence_unavailable`，不能由模型补写。

### 2.2.3 Zone、证据块与完整 RAG 层

- Zone A–D 是语义/分析分区，不是 token 分片；
- evidence block 是可回溯的段落、公式、算法、表格或图注；
- context window 是模型调用的技术装载单位，不产生新的语义 Zone；
- 完整 RAG 必须包含 evidence indexing、embedding、BM25/向量混合检索、上下文组装、生成、引用核验和 retrieval manifest；
- Agent A 同时执行全文 coverage pass 和 D01–D10 维度 retrieval pass，避免 Top-k 检索造成全文漏召回。

## 2.3 Step 2：真正的双大语言模型智能体十维知识抽取

### 2.3.1 Agent A：Full-Text Ontology Extractor

Agent A 接收单篇论文的 Zone A–D 全文切片和十维 Schema，逐维输出：

- 受控标签；
- 机制性判断；
- 不确定性说明；
- 至少一条正文证据；
- 章节号、页码、evidence_id 和原文字符区间；
- 涉及公式时记录公式编号、变量、物理含义和公式所在页码。

严格规则：

- 没有正文证据时只能输出 `Not_Stated_In_Text`；
- 不得仅凭标题、摘要、关键词推断 D02–D09；
- 不得把引用文献的方法误认作当前论文的方法；
- 不得把 HLA/软件数据交换自动解释为真实 cyber 早期预警；
- 不得把一般水网压力方程自动解释为厂内冷却热-水力模型。

### 2.3.2 Agent B：Independent Critic and Evidence Auditor

Agent B 独立读取原始四区切片和 Agent A 输出，不能读取 Agent A 的推理过程。对每一条维度记录执行：

1. **Entailment check**：原文是否支持该标签和机理判断；
2. **Direction check**：水→电、电→水或双向关系是否被正确识别；
3. **Equation check**：是否真的存在所声称的方程、变量和动态过程；
4. **Temporal check**：时间步长、仿真推进和控制触发条件是否被准确表述；
5. **Endpoint check**：物理、经济、人类/社会后果是否被混淆；
6. **Evidence check**：section、page、evidence_id 和 verbatim quote 是否精确对应；
7. **Contradiction check**：文中是否存在反向或限制性证据。

Agent B 必须输出：

```json
{
  "decision": "accept | revise | reject | insufficient_evidence",
  "corrected_label": "...",
  "critic_comment": "...",
  "supporting_evidence_ids": ["..."],
  "contradicting_evidence_ids": ["..."],
  "confidence": 0.0
}
```

### 2.3.3 双智能体迭代协议

采用以下可审计循环：

```text
Step 1 retained full-text slices
        ↓
Agent A 初次十维抽取
        ↓
Agent B 独立 Critic 审查
        ↓
Agent A 根据 Critic 修订
        ↓
Agent B 最终复核
        ↓
verified_10d_record
```

若 Agent A 与 Agent B 仍存在分歧，不强行投票，保留：

```text
adjudication_required = true
```

并进入人工复核清单。

### 2.3.4 模型调用审计

每次大语言模型调用必须写入 `model_call_manifest.csv`：

- agent_name；
- provider；
- model_name；
- model_version；
- endpoint；
- prompt_version；
- input_hash；
- output_hash；
- temperature；
- seed（若可用）；
- input/output tokens；
- retry 次数；
- 调用时间；
- 失败原因。

本章节不预先虚构具体模型名称。实际运行前必须锁定 Agent A 和 Agent B 的可用长上下文模型，并在 manifest 中记录；在没有模型调用日志前，不得称为“LLM 已完成抽取”。

## 2.4 Step 3：基于已核验 LLM 记录的语义综合与前沿识别

### 2.4.1 LLM 语义综合 Agent

Step 3 不再用人工 `PROFILES`、关键词命中或固定模板直接生成研究结论。将通过 Agent B 的 Corpus Synthesis 模式，对已通过 Step 2 的 300 条十维记录进行跨文献综合，输出：

- 研究范式簇；
- 每个簇的共同机制；
- 代表性证据和反例证据；
- 研究空白陈述；
- 空白对应的第 3、4、5 章；
- 候选前沿方向的边界条件和不可外推范围。

所有候选方向必须绑定至少 3 个 `evidence_id`，并同时列出反向证据或未充分证据。

### 2.4.2 数值化 FRDI

FRDI 保留透明的数值计算，但数值输入必须来自已核验 LLM 记录，而不是人工硬编码标签：

\[
FRDI_k = \omega_1 ESI_k + \omega_2 TGM_k + \omega_3 LCI_k
\]

其中：

- `ESI`：基于已核验标签和证据覆盖率计算的领域稀缺度；
- `TGM`：按出版年份和证据支持的方向演化计算的时间动量；
- `LCI`：由 Agent B 对作者明确局限性与候选研究方向的证据关联进行 0–3 级评分，再由 Python 固定公式聚合；
- 权重、归一化方式和缺失值处理在执行前冻结，不允许根据结果反向调参。

Python 仅负责可重复的统计计算、置信区间、敏感性分析和制图；不负责替代大语言模型完成语义判断。

### 2.4.3 可选语义聚类

UMAP/HDBSCAN 仅作为辅助稳健性分析，不作为主要知识抽取方法：

- 输入：Agent A/B 已核验的机制摘要和局限性摘要；
- 嵌入模型、版本和距离度量必须记录；
- 聚类标签必须由 Agent B 根据簇内 evidence_id 重新解释；
- 不能把无监督簇直接命名为研究方向而不提供正文证据。

## 2.5 方法有效性与人工复核

### 2.5.1 Pilot gate

先用两个受控 benchmark PDF 执行真实 LLM 双智能体流程。只有满足以下条件，才能扩展到 30 篇：

- 20 个维度记录均有有效 evidence_id；
- 原文证据可由程序精确回溯；
- Agent A/B 对关键标签的最终一致率达到预设阈值；
- D02、D04、D05、D06、D08 等关键难点由领域专家人工抽查；
- 所有模型调用均有 manifest 和 prompt 版本记录。

### 2.5.2 人工金标准抽查

从 30 篇中分层抽取至少 5 篇、50 条维度记录，由领域研究者盲审：

- 标签准确率；
- 证据充分率；
- 页码/章节回溯准确率；
- 误把引用方法归为本文方法的比例；
- D02 厂内冷却识别的精确率；
- D08 人类与社会影响识别的精确率。

### 2.5.3 结果表述边界

`accept` 只表示证据支持该判断，不表示论文结论本身正确；`insufficient_evidence` 不得被改写为 `Not_Considered`；规则化 quote-match 只能验证溯源，不能替代语义 Critic。

## 2.6 30 篇语料执行顺序与输出

1. 保留 Step 1，不重复 PDF 版面切片；
2. 重新锁定 Agent A/B 模型、提示词、Schema 和 manifest；
3. 先对两个 benchmark PDF 进行真实 LLM pilot；
4. 通过 pilot gate 后处理 Batch 001–003 的 30 篇；
5. 以 verified records 执行 Step 3 LLM 语义综合和 FRDI；
6. 重新生成第 2.1–2.4 节图表。

推荐输出目录：

```text
02_llm_pdf_mining_pipeline/v2_llm_execution/
├── prompt_registry/
├── model_call_manifest.csv
├── step2_agent_a_raw/
├── step2_agent_b_critic/
├── step2_verified_final/
├── step3_llm_synthesis/
├── human_audit/
└── figures_2-1_to_2-4/
```

旧规则化结果已从第2章活动目录清理；两篇受控 benchmark 的历史结果仅保存在 `/home/user/_protected_benchmark_archive/`，不得与 v2 真实 LLM 结果混用。
