# Batch 003 Step 1：PDF 全文章节树与四区靶向切片

**范围：**10 篇新上传 PDF；本轮执行 Step 1，Step 2/Step 3 暂不执行。

| Batch文献 | Cleaned_ID | 页数 | 原文词数 | 靶向保留 | 剥离噪声 | 降噪率 | 章节数 |
|---|---:|---:|---:|---:|---:|---:|---:|
| B003-PDF-01 | 63 | 14 | 12197 | 10732 | 1465 | 12.01% | 9 |
| B003-PDF-02 | 66 | 21 | 13018 | 9790 | 3228 | 24.8% | 28 |
| B003-PDF-03 | 70 | 17 | 14208 | 10859 | 3349 | 23.57% | 27 |
| B003-PDF-04 | 79 | 14 | 10941 | 10005 | 936 | 8.55% | 11 |
| B003-PDF-05 | 82 | 16 | 9790 | 7108 | 2682 | 27.4% | 23 |
| B003-PDF-06 | 94 | 11 | 9690 | 7717 | 1973 | 20.36% | 12 |
| B003-PDF-07 | 100 | 14 | 13036 | 8029 | 5007 | 38.41% | 16 |
| B003-PDF-08 | 105 | 12 | 9920 | 8241 | 1679 | 16.93% | 8 |
| B003-PDF-09 | 108 | 10 | 7855 | 7616 | 239 | 3.04% | 6 |
| B003-PDF-10 | 111 | 14 | 12533 | 9744 | 2789 | 22.25% | 16 |

## 章节树与四区映射

### B003-PDF-01 / Cleaned_ID 63：Resilience Analytics for Interdependent Power and Water Distribution Systems

- 文件：`8_Resilience_Analytics_for_Interdependent_Power_and_Water_Distribution_Systems.pdf`；PDF页数：14；解析题名：Resilience Analytics for Interdependent Power and Water Distribution Systems；期刊/年份：IEEE TRANSACTIONS ON POWER SYSTEMS (2022)

| 章节号 | 章节标题 | 页码 | 词数 | 区域 |
|---|---|---|---:|---|
| `C.` | C. Variables | P2-P2 | 332 | Zone B (Coupling & Cascading Methodology) |
| `I.` | I. INTRODUCTION | P2-P4 | 1715 | Zone A (Kept Core Contribution) + Stripped (Early Intro) |
| `II.` | II. OVERVIEW OF THE PROPOSED MODEL | P4-P5 | 848 | Zone B (Coupling & Cascading Methodology) |
| `III.` | III. OUTAGE ANALYSIS IN INTERDEPENDENT POWER AND | P5-P6 | 1523 | Zone B (Coupling & Cascading Methodology) |
| `C.` | C. Cascading Water Shortage Analysis Model | P6-P7 | 1050 | Zone B (Coupling & Cascading Methodology) |
| `IV.` | IV. RESILIENCE METRICS FOR INTERDEPENDENT POWER AND | P7-P9 | 1015 | Zone B (Coupling & Cascading Methodology) |
| `V.` | V. NUMERICAL STUDY | P9-P11 | 1570 | Zone B (Coupling & Cascading Methodology) |
| `4.` | 4. Although it represents an improvement compared to the case | P11-P12 | 1063 | Zone B (Coupling & Cascading Methodology) |
| `VI.` | VI. CONCLUSION | P12-P14 | 2558 | Zone D (Case Setup, Social/Human Context & Limitations) |

### B003-PDF-02 / Cleaned_ID 66：Interdependent effects of critical infrastructure systems under different types of disruptions

- 文件：`4560.pdf`；PDF页数：21；解析题名：Interdependent effects of critical infrastructure systems under different types of disruptions；期刊/年份：INTERNATIONAL JOURNAL OF DISASTER RISK REDUCTION (2022)

| 章节号 | 章节标题 | 页码 | 词数 | 区域 |
|---|---|---|---:|---|
| `1.` | 1. Introduction | P1-P2 | 1213 | Zone A (Kept Core Contribution) + Stripped (Early Intro) |
| `2.` | 2. Related works | P3-P3 | 0 | Stripped_Noise (Related Work Review) |
| `2.1.` | 2.1. Modeling interdependent CISs | P3-P3 | 0 | Zone B (Coupling & Cascading Methodology) |
| `2.2.` | 2.2. Modeling and quantifying the interdependencies between CISs | P3-P3 | 966 | Zone B (Coupling & Cascading Methodology) |
| `2.3.` | 2.3. Modeling different types of CIS disruptions | P4-P4 | 0 | Zone B (Coupling & Cascading Methodology) |
| `2.4.` | 2.4. Assessing the impact of CIS disruptions | P4-P4 | 1066 | Zone B (Coupling & Cascading Methodology) |
| `3.` | 3. Methodology | P5-P5 | 0 | Zone B (Coupling & Cascading Methodology) |
| `3.1.` | 3.1. Modeling interdependent CISs using co-simulation approach | P5-P5 | 294 | Zone B (Coupling & Cascading Methodology) |
| `3.2.` | 3.2. Simulating different types of disruptions | P6-P7 | 1792 | Zone B (Coupling & Cascading Methodology) |
| `3.3.` | 3.3. Assessing the disruption impact and interdependent effect | P8-P8 | 14 | Zone B (Coupling & Cascading Methodology) |
| `4.` | 4. Case study | P8-P8 | 0 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `4.1.` | 4.1. Power and water systems | P8-P8 | 813 | Zone B (Coupling & Cascading Methodology) |
| `4.2.` | 4.2. System interdependencies | P9-P9 | 0 | Zone B (Coupling & Cascading Methodology) |
| `4.3.` | 4.3. Model development and disruption simulation | P9-P10 | 800 | Zone B (Coupling & Cascading Methodology) |
| `5.` | 5. Results | P11-P11 | 0 | Zone B (Coupling & Cascading Methodology) |
| `5.1.` | 5.1. Random disruptions | P11-P13 | 747 | Zone B (Coupling & Cascading Methodology) |
| `5.2.` | 5.2. Topology-based intentional disruptions | P14-P14 | 349 | Zone B (Coupling & Cascading Methodology) |
| `5.3.` | 5.3. Flow-based intentional disruptions | P15-P16 | 370 | Zone B (Coupling & Cascading Methodology) |
| `5.4.` | 5.4. Interdependent effects | P17-P18 | 197 | Zone B (Coupling & Cascading Methodology) |
| `6.` | 6. Discussions | P18-P18 | 0 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `6.1.` | 6.1. Main findings | P18-P18 | 925 | Zone B (Coupling & Cascading Methodology) |
| `6.2.` | 6.2. Implications of study findings | P19-P19 | 0 | Zone B (Coupling & Cascading Methodology) |
| `6.3.` | 6.3. Study limitations | P19-P19 | 0 | Zone B (Coupling & Cascading Methodology) |
| `7.` | 7. Conclusions | P19-P19 | 976 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `Declaration of competing interest` | Declaration of competing interest | P20-P20 | 0 | Stripped_Noise (References/Ack) |
| `Data availability` | Data availability | P20-P20 | 9 | Stripped_Noise (References/Ack) |
| `Acknowledgments` | Acknowledgments | P20-P20 | 0 | Stripped_Noise (References/Ack) |
| `References` | References | P20-P21 | 2265 | Stripped_Noise (References/Ack) |

### B003-PDF-03 / Cleaned_ID 70：Assessing the impact of systemic heterogeneity on failure propagation across interdependent critical infrastructure systems

- 文件：`2365_Assessing the impact of systemic heterogeneity on failure propagation across interdependent critical infrastructure systems.pdf`；PDF页数：17；解析题名：Assessing the impact of systemic heterogeneity on failure propagation across interdependent critical infrastructure systems；期刊/年份：INTERNATIONAL JOURNAL OF DISASTER RISK REDUCTION (2020)

| 章节号 | 章节标题 | 页码 | 词数 | 区域 |
|---|---|---|---:|---|
| `1.` | 1. Introduction | P1-P2 | 924 | Zone A (Kept Core Contribution) + Stripped (Early Intro) |
| `2.` | 2. Related work | P2-P2 | 0 | Stripped_Noise (Related Work Review) |
| `2.1.` | 2.1. Approaches for modeling CISs | P2-P3 | 772 | Stripped_Noise (Related Work Review) |
| `2.2.` | 2.2. Simulation of failure propagation across CISs | P3-P3 | 1032 | Zone B (Coupling & Cascading Methodology) |
| `3.` | 3. Methodology | P3-P4 | 264 | Zone B (Coupling & Cascading Methodology) |
| `3.1.` | 3.1. Fragility models of CISs components | P4-P4 | 69 | Zone B (Coupling & Cascading Methodology) |
| `3.1.1.` | 3.1.1. Fragility model of nodes | P4-P4 | 356 | Zone B (Coupling & Cascading Methodology) |
| `3.1.2.` | 3.1.2. Fragility model of pipelines | P4-P4 | 367 | Zone B (Coupling & Cascading Methodology) |
| `3.2.` | 3.2. Artificial flow-based network model | P4-P5 | 653 | Zone B (Coupling & Cascading Methodology) |
| `3.3.` | 3.3. Improved models | P5-P6 | 796 | Zone B (Coupling & Cascading Methodology) |
| `3.4.` | 3.4. Impact metrics | P6-P7 | 586 | Zone B (Coupling & Cascading Methodology) |
| `4.` | 4. Case study | P7-P7 | 0 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `4.1.` | 4.1. Case description | P7-P8 | 461 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `4.2.` | 4.2. Heterogeneity factors | P8-P10 | 1258 | Zone B (Coupling & Cascading Methodology) |
| `4.3.` | 4.3. Development of the improved models | P10-P10 | 856 | Zone B (Coupling & Cascading Methodology) |
| `5.` | 5. Assessment results and analysis | P10-P10 | 328 | Zone B (Coupling & Cascading Methodology) |
| `5.1.` | 5.1. Failure propagation time and scale | P10-P11 | 493 | Zone B (Coupling & Cascading Methodology) |
| `5.2.` | 5.2. Failure propagation sequence | P11-P11 | 297 | Zone B (Coupling & Cascading Methodology) |
| `5.3.` | 5.3. Impact assessment results | P11-P13 | 386 | Zone B (Coupling & Cascading Methodology) |
| `5.4.` | 5.4. Sensitivity analysis | P13-P13 | 126 | Zone C (Metrics, Simulation & Resilience Evaluation) |
| `5.4.1.` | 5.4.1. Sensitivity analysis of impact assessment results to the tolerance | P13-P13 | 431 | Zone C (Metrics, Simulation & Resilience Evaluation) |
| `5.4.2.` | 5.4.2. Sensitivity analysis of impact assessment results to the PGA | P13-P14 | 253 | Zone C (Metrics, Simulation & Resilience Evaluation) |
| `6.` | 6. Discussions | P14-P15 | 565 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `7.` | 7. Conclusions | P15-P16 | 550 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `Declaration of competing interest` | Declaration of competing interest | P16-P16 | 28 | Stripped_Noise (References/Ack) |
| `Acknowledgments` | Acknowledgments | P16-P16 | 107 | Stripped_Noise (References/Ack) |
| `References` | References | P16-P17 | 1757 | Stripped_Noise (References/Ack) |

### B003-PDF-04 / Cleaned_ID 79：Human-Centered Infrastructure Restoration: An Integrated Framework for Demand Estimation and Resource Allocation

- 文件：`4128_Human‐Centered Infrastructure Restoration  An Integrated Framework for Demand Estimation and.pdf`；PDF页数：14；解析题名：Human-Centered Infrastructure Restoration: An Integrated Framework for Demand Estimation and Resource Allocation；期刊/年份：RISK ANALYSIS (2026)

| 章节号 | 章节标题 | 页码 | 词数 | 区域 |
|---|---|---|---:|---|
| `1` | Introduction | P1-P1 | 481 | Zone A (Meta, Abstract & Core Contribution) |
| `2` | Literature Review on Infrastructure Restorations | P2-P2 | 1051 | Zone A (Meta, Abstract & Core Contribution) |
| `3` | Problem Statement | P3-P4 | 1652 | Zone A (Meta, Abstract & Core Contribution) |
| `4` | Methodology | P5-P5 | 865 | Zone B (Coupling & Cascading Methodology) |
| `4.1` | Bayesian-Based Estimation of Demand | P5-P5 | 865 | Zone B (Coupling & Cascading Methodology) |
| `4.2` | Demand-Oriented Resource Optimization Model | P6-P7 | 1457 | Zone B (Coupling & Cascading Methodology) |
| `4.3` | Solution Methods | P8-P8 | 989 | Zone B (Coupling & Cascading Methodology) |
| `5` | Case Study and Results | P9-P11 | 1977 | Zone C (Metrics, Simulation & Resilience Evaluation) |
| `6` | Discussion | P12-P12 | 568 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `7` | Conclusion | P13-P13 | 991 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `Back` | Acknowledgments and References | P14-P14 | 938 | Stripped_Noise (References/Ack) |

### B003-PDF-05 / Cleaned_ID 82：Vulnerability analyses of power-water interdependent infrastructure networks by using load-functional dependency coupled cascading failure model

- 文件：`1064_Vulnerability analyses of power-water interdependent infrastructure networks by using load-functional dependency coupled cascading failure model.pdf`；PDF页数：16；解析题名：Vulnerability analyses of power-water interdependent infrastructure networks by using load-functional dependency coupled cascading failure model；期刊/年份：RELIABILITY ENGINEERING & SYSTEM SAFETY (2027)

| 章节号 | 章节标题 | 页码 | 词数 | 区域 |
|---|---|---|---:|---|
| `1.` | 1. Introduction | P1-P3 | 1150 | Zone A (Kept Core Contribution) + Stripped (Early Intro) |
| `2.` | 2. Methodology | P3-P3 | 55 | Zone B (Coupling & Cascading Methodology) |
| `2.1.` | 2.1. Power-water interdependent infrastructure network considering | P3-P4 | 674 | Zone B (Coupling & Cascading Methodology) |
| `2.2.` | 2.2. Load-functional dependency coupled cascading failure model | P4-P4 | 268 | Zone B (Coupling & Cascading Methodology) |
| `2.2.1.` | 2.2.1. Load cascading failure | P4-P5 | 428 | Zone B (Coupling & Cascading Methodology) |
| `2.2.2.` | 2.2.2. Functional dependency | P5-P5 | 243 | Zone B (Coupling & Cascading Methodology) |
| `2.2.3.` | 2.2.3. The dynamic coupling and feedback mechanism of load failure and | P5-P6 | 489 | Zone B (Coupling & Cascading Methodology) |
| `2.3.` | 2.3. Simulation procedure of the coupled cascading failure model | P6-P6 | 0 | Zone B (Coupling & Cascading Methodology) |
| `2.3.1.` | 2.3.1. Attack strategy | P6-P7 | 476 | Zone B (Coupling & Cascading Methodology) |
| `2.3.2.` | 2.3.2. Simulation iteration | P7-P7 | 405 | Zone B (Coupling & Cascading Methodology) |
| `2.3.3.` | 2.3.3. Time complexity of the simulation procedure | P7-P8 | 231 | Zone B (Coupling & Cascading Methodology) |
| `3.` | 3. Validation and discussion | P8-P8 | 174 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `3.1.` | 3.1. Network vulnerability analyses under intentional attacks | P8-P8 | 0 | Zone B (Coupling & Cascading Methodology) |
| `3.1.1.` | 3.1.1. Comparative analyses of different cascading failure models | P8-P8 | 451 | Zone B (Coupling & Cascading Methodology) |
| `3.1.2.` | 3.1.2. Analyses of contribution factors for system functionality degradation | P8-P9 | 416 | Zone B (Coupling & Cascading Methodology) |
| `3.1.3.` | 3.1.3. Cascading failure propagation characteristics of an ordinary node | P9-P11 | 952 | Zone B (Coupling & Cascading Methodology) |
| `3.1.4.` | 3.1.4. Sensitivity analysis of dependency coefficients | P11-P12 | 280 | Zone C (Metrics, Simulation & Resilience Evaluation) |
| `3.2.` | 3.2. Network vulnerability analyses under regional attacks | P12-P13 | 443 | Zone B (Coupling & Cascading Methodology) |
| `4.` | 4. Conclusions and future work | P13-P15 | 462 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `CRediT authorship contribution statement` | CRediT authorship contribution statement | P15-P15 | 25 | Stripped_Noise (References/Ack) |
| `Declaration of competing interest` | Declaration of competing interest | P15-P15 | 66 | Stripped_Noise (References/Ack) |
| `Data availability` | Data availability | P15-P15 | 9 | Stripped_Noise (References/Ack) |
| `References` | References | P15-P16 | 1686 | Stripped_Noise (References/Ack) |

### B003-PDF-06 / Cleaned_ID 94：A socio-technical approach for the assessment of critical infrastructure system vulnerability in extreme weather events

- 文件：`25_A socio-technical approach for the assessment of critical infrastructure system vulnerability in extreme weather events.pdf`；PDF页数：11；解析题名：A socio-technical approach for the assessment of critical infrastructure system vulnerability in extreme weather events；期刊/年份：NATURE ENERGY (2023)

| 章节号 | 章节标题 | 页码 | 词数 | 区域 |
|---|---|---|---:|---|
| `A` | Study context and background | P1-P1 | 555 | Zone A (Meta, Abstract & Core Contribution) |
| `B1` | Modelling of the water infrastructure | P2-P2 | 1315 | Zone B (Coupling & Cascading Methodology) |
| `B2` | Flood modelling | P2-P2 | 1315 | Zone B (Coupling & Cascading Methodology) |
| `B3` | Modelling of the power infrastructure | P2-P3 | 1861 | Zone B (Coupling & Cascading Methodology) |
| `C1` | Integrated scenarios | P4-P4 | 1226 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `C2` | Power–water coupling | P4-P4 | 1226 | Zone B (Coupling & Cascading Methodology) |
| `C3` | Socio-technical analysis | P4-P6 | 2231 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `D1` | Results of socio-technical vulnerability and service loss | P7-P7 | 817 | Zone C (Metrics, Simulation & Resilience Evaluation) |
| `D2` | Conclusions | P8-P8 | 1142 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `E1` | Methods | P8-P8 | 1142 | Zone B (Coupling & Cascading Methodology) |
| `E2` | Limitations | P9-P9 | 1129 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `Back` | Data availability and references | P10-P11 | 1977 | Stripped_Noise (References/Ack) |

### B003-PDF-07 / Cleaned_ID 100：A water-electricity nexus model to analyze thermoelectricity supply reliability under environmental regulations and economic penalties during drought events

- 文件：`406_A water-electricity nexus model to analyze thermoelectricity supply reliability under environmental regulations and economic penalties during drought events.pdf`；PDF页数：14；解析题名：A water-electricity nexus model to analyze thermoelectricity supply reliability under environmental regulations and economic penalties during drought events；期刊/年份：ENVIRONMENTAL MODELLING & SOFTWARE (2020)

| 章节号 | 章节标题 | 页码 | 词数 | 区域 |
|---|---|---|---:|---|
| `1.` | 1. Introduction | P1-P4 | 2301 | Zone A (Kept Core Contribution) + Stripped (Early Intro) |
| `2.` | 2. Methods | P4-P4 | 177 | Zone B (Coupling & Cascading Methodology) |
| `2.1.` | 2.1. The hydrologic module: HSPF | P4-P4 | 264 | Zone B (Coupling & Cascading Methodology) |
| `2.2.` | 2.2. The decentralized optimization module | P4-P5 | 660 | Zone B (Coupling & Cascading Methodology) |
| `2.3.` | 2.3. The thermoelectricity generation module | P5-P6 | 1013 | Zone B (Coupling & Cascading Methodology) |
| `3.` | 3. Case study and data | P6-P6 | 0 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `3.1.` | 3.1. Case study description | P6-P6 | 505 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `3.2.` | 3.2. Input data | P6-P7 | 732 | Zone B (Coupling & Cascading Methodology) |
| `4.` | 4. Results | P7-P7 | 0 | Zone B (Coupling & Cascading Methodology) |
| `4.1.` | 4.1. Electricity supply under varying environmental constraint relaxation | P7-P7 | 588 | Zone B (Coupling & Cascading Methodology) |
| `4.2.` | 4.2. Electricity supply under fixed environmental constraint relaxation | P7-P9 | 787 | Zone B (Coupling & Cascading Methodology) |
| `4.3.` | 4.3. Electricity supply under varying environmental constraint relaxation | P9-P10 | 1167 | Zone B (Coupling & Cascading Methodology) |
| `4.4.` | 4.4. Sensitivity analysis of electricity supply to the market electricity price | P10-P11 | 477 | Zone C (Metrics, Simulation & Resilience Evaluation) |
| `5.` | 5. Conclusions and discussion | P11-P11 | 1092 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `Acknowledgment` | Acknowledgment | P11-P12 | 345 | Stripped_Noise (References/Ack) |
| `References` | References | P13-P14 | 2620 | Stripped_Noise (References/Ack) |

### B003-PDF-08 / Cleaned_ID 105：Joint Cascade Vulnerability Assessment of Interdependent Power-Water Infrastructures

- 文件：`48_Joint_Cascade_Vulnerability_Assessment_of_Interdependent_PowerWater_Infrastructures.pdf`；PDF页数：12；解析题名：Joint Cascade Vulnerability Assessment of Interdependent Power-Water Infrastructures；期刊/年份：IEEE SYSTEMS JOURNAL (2023)

| 章节号 | 章节标题 | 页码 | 词数 | 区域 |
|---|---|---|---:|---|
| `I.` | I. INTRODUCTION AND MOTIVATION | P2-P3 | 1945 | Zone A (Kept Core Contribution) + Stripped (Early Intro) |
| `II.` | II. INTERDEPENDENT POWER–WATER MODEL | P3-P4 | 355 | Zone B (Coupling & Cascading Methodology) |
| `C.` | C. Interdependencies Modeling | P4-P5 | 1013 | Zone B (Coupling & Cascading Methodology) |
| `III.` | III. CRITICALITY ASSESSMENT | P5-P6 | 1237 | Zone B (Coupling & Cascading Methodology) |
| `IV.` | IV. JOINT CFS | P6-P7 | 1132 | Zone B (Coupling & Cascading Methodology) |
| `V.` | V. JOINT VULNERABILITY ANALYSIS | P7-P8 | 793 | Zone B (Coupling & Cascading Methodology) |
| `VI.` | VI. EXPERIMENTAL ANALYSIS | P8-P11 | 1541 | Zone B (Coupling & Cascading Methodology) |
| `VII.` | VII. CONCLUSION | P11-P12 | 1630 | Zone D (Case Setup, Social/Human Context & Limitations) |

### B003-PDF-09 / Cleaned_ID 108：Seasonal Risk Assessment of Water-Electricity Nexus Systems under Water Consumption Policy Constraint

- 文件：`874_Seasonal Risk Assessment of Water–Electricity Nexus Systems under Water Consumption Policy Constraint.pdf`；PDF页数：10；解析题名：Seasonal Risk Assessment of Water-Electricity Nexus Systems under Water Consumption Policy Constraint；期刊/年份：ENVIRONMENTAL SCIENCE & TECHNOLOGY (2020)

| 章节号 | 章节标题 | 页码 | 词数 | 区域 |
|---|---|---|---:|---|
| `1.` | 1. INTRODUCTION | P1-P2 | 493 | Zone A (Kept Core Contribution) + Stripped (Early Intro) |
| `2.` | 2. MATERIALS AND METHODS | P2-P4 | 2173 | Zone B (Coupling & Cascading Methodology) |
| `3.` | 3. RESULTS | P4-P4 | 158 | Zone B (Coupling & Cascading Methodology) |
| `3.1.` | 3.1. Cooling Water Consumption Percentage under | P4-P7 | 1999 | Zone B (Coupling & Cascading Methodology) |
| `3.3.` | 3.3. The Necessity of Considering Variable Cooling | P7-P7 | 136 | Zone B (Coupling & Cascading Methodology) |
| `4.` | 4. DISCUSSION | P7-P10 | 2848 | Zone D (Case Setup, Social/Human Context & Limitations) |

### B003-PDF-10 / Cleaned_ID 111：Co-optimization of power and water distribution systems for simultaneous hydropower generation and water pressure regulation

- 文件：`439_Co-optimization of power and water distribution systems for simultaneous hydropower generation and water pressure regulation.pdf`；PDF页数：14；解析题名：Co-optimization of power and water distribution systems for simultaneous hydropower generation and water pressure regulation；期刊/年份：ENERGY REPORTS (2024)

| 章节号 | 章节标题 | 页码 | 词数 | 区域 |
|---|---|---|---:|---|
| `1.` | 1. Introduction | P1-P3 | 2092 | Zone A (Kept Core Contribution) + Stripped (Early Intro) |
| `2.` | 2. Water distribution system model | P3-P3 | 45 | Zone B (Coupling & Cascading Methodology) |
| `2.1.` | 2.1. Water pressure regulation using hydro-turbines | P3-P3 | 527 | Zone B (Coupling & Cascading Methodology) |
| `2.2.` | 2.2. The hydro-turbine as link between WDS and PDS | P3-P6 | 2050 | Zone B (Coupling & Cascading Methodology) |
| `3.` | 3. Power distribution system model | P6-P6 | 960 | Zone B (Coupling & Cascading Methodology) |
| `4.` | 4. The interconnected power and water distribution system | P7-P7 | 1012 | Zone B (Coupling & Cascading Methodology) |
| `5.` | 5. Simulation results | P7-P7 | 0 | Zone B (Coupling & Cascading Methodology) |
| `5.1.` | 5.1. Example: IPWDS Description | P7-P9 | 950 | Zone B (Coupling & Cascading Methodology) |
| `5.2.` | 5.2. Base case | P9-P9 | 351 | Zone B (Coupling & Cascading Methodology) |
| `5.3.` | 5.3. Co-optimization | P9-P13 | 1643 | Zone B (Coupling & Cascading Methodology) |
| `6.` | 6. Conclusion | P13-P14 | 1139 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `CRediT authorship contribution statement` | CRediT authorship contribution statement | P14-P14 | 41 | Stripped_Noise (References/Ack) |
| `Data availability` | Data availability | P14-P14 | 17 | Stripped_Noise (References/Ack) |
| `Acknowledgments` | Acknowledgments | P14-P14 | 37 | Stripped_Noise (References/Ack) |
| `References` | References | P14-P14 | 869 | Stripped_Noise (References/Ack) |
| `1995` | 1995 Bibliography on Load Models for Power Flow and Dynamic Performance | P14-P14 | 409 | Zone B (Coupling & Cascading Methodology) |

