# Batch 002 Step 1：PDF 全文章节树与四区靶向切片

**范围：**10 篇新上传 PDF；本轮仅执行 Step 1，Step 2/Step 3 保持待执行。

| Batch 文献 | Cleaned_ID | PDF页数 | 原文词数 | 靶向保留词数 | 剥离噪声词数 | 降噪率 | 章节数 |
|---|---:|---:|---:|---:|---:|---:|---:|
| B002-PDF-01 | 29 | 23 | 11329 | 10510 | 819 | 7.23% | 18 |
| B002-PDF-02 | 33 | 13 | 8566 | 5738 | 2828 | 33.01% | 18 |
| B002-PDF-03 | 36 | 11 | 9577 | 8487 | 1090 | 11.38% | 7 |
| B002-PDF-04 | 38 | 14 | 11213 | 9464 | 1749 | 15.6% | 42 |
| B002-PDF-05 | 39 | 11 | 12067 | 10714 | 1353 | 11.21% | 6 |
| B002-PDF-06 | 46 | 13 | 14262 | 10137 | 4125 | 28.92% | 8 |
| B002-PDF-07 | 54 | 14 | 13864 | 11724 | 2140 | 15.44% | 29 |
| B002-PDF-08 | 58 | 24 | 15571 | 12066 | 3505 | 22.51% | 32 |
| B002-PDF-09 | 59 | 20 | 13409 | 10619 | 2790 | 20.81% | 38 |
| B002-PDF-10 | 60 | 15 | 10960 | 9292 | 1668 | 15.22% | 10 |

## 章节树与区域映射

### B002-PDF-01 / Cleaned_ID 29：Assessment of the impact of interdependencies on the resilience of networked critical infrastructure systems

- PDF文件：`1596_Assessment of the impact of interdependencies on t.pdf`；页数：23；解析题名：Assessment of the impact of interdependencies on the resilience of networked critical infrastructure systems；期刊/年份：Natural Hazards (2025)

| 章节号 | 章节标题 | 页码 | 词数 | 区域 |
|---|---|---|---:|---|
| `1` | 1 Introduction | P2-P2 | 565 | Zone A (Kept Core Contribution) + Stripped (Early Intro) |
| `2` | 2 Literature review | P3-P3 | 350 | Zone B (Coupling & Cascading Methodology) |
| `2.1` | 2.1 Quantitative assessment of resilience of networked CISs | P3-P5 | 1087 | Zone B (Coupling & Cascading Methodology) |
| `2.2` | 2.2 Effects of interdependencies in the context of disaster risk reduction | P5-P5 | 309 | Zone B (Coupling & Cascading Methodology) |
| `3` | 3 Representative models and metrics | P6-P6 | 0 | Zone B (Coupling & Cascading Methodology) |
| `3.1` | 3.1 Network-based models | P6-P6 | 0 | Zone B (Coupling & Cascading Methodology) |
| `3.1.1` | 3.1.1 Related work | P6-P6 | 483 | Stripped_Noise (Related Work Review) |
| `3.1.2` | 3.1.2 Selected modeling approaches | P7-P7 | 621 | Zone B (Coupling & Cascading Methodology) |
| `3.2` | 3.2 Resilience metrics | P8-P9 | 1127 | Zone B (Coupling & Cascading Methodology) |
| `4.1` | 4.1 Case city | P10-P10 | 38 | Zone B (Coupling & Cascading Methodology) |
| `4` | 4 Model implementation and resilience assessment | P10-P11 | 217 | Zone B (Coupling & Cascading Methodology) |
| `4.2` | 4.2 Hazard simulation | P11-P11 | 0 | Zone B (Coupling & Cascading Methodology) |
| `4.3` | 4.3 Disturbance propagation simulation | P11-P12 | 703 | Zone B (Coupling & Cascading Methodology) |
| `4.4` | 4.4 Restoration simulation | P13-P13 | 571 | Zone B (Coupling & Cascading Methodology) |
| `4.5` | 4.5 Resilience assessment | P14-P14 | 0 | Zone B (Coupling & Cascading Methodology) |
| `5` | 5 Simulation results | P14-P18 | 1359 | Zone B (Coupling & Cascading Methodology) |
| `6` | 6 Discussion | P18-P18 | 449 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `7` | 7 Conclusions | P19-P23 | 3244 | Zone D (Case Setup, Social/Human Context & Limitations) |

**剥离项：** 1 Introduction (Early Background Review Part)（336词，Introduction Background Literature Review）；3.1.1 Related work（483词，Related Work (Literature Review of Other Papers)）

### B002-PDF-02 / Cleaned_ID 33：Vulnerability analysis of water systems to power interruptions in critical infrastructures

- PDF文件：`328_Vulnerability analysis of water systems to power interruptions in critical infrastructures.pdf`；页数：13；解析题名：Vulnerability analysis of water systems to power interruptions in critical infrastructures；期刊/年份：Sustainable Energy (2026)

| 章节号 | 章节标题 | 页码 | 词数 | 区域 |
|---|---|---|---:|---|
| `1.` | 1. Introduction | P1-P2 | 1129 | Zone A (Kept Core Contribution) + Stripped (Early Intro) |
| `2.` | 2. Vulnerability analysis for water and power systems | P2-P2 | 0 | Zone B (Coupling & Cascading Methodology) |
| `2.1.` | 2.1. Failure propagation mechanism | P2-P2 | 163 | Zone B (Coupling & Cascading Methodology) |
| `2.2.` | 2.2. Cascading model | P2-P3 | 579 | Zone B (Coupling & Cascading Methodology) |
| `2.3.` | 2.3. Vulnerability analysis | P3-P4 | 775 | Zone B (Coupling & Cascading Methodology) |
| `3.` | 3. Case study | P4-P4 | 0 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `3.1.` | 3.1. Base information | P4-P5 | 411 | Zone B (Coupling & Cascading Methodology) |
| `3.2.` | 3.2. Scenario setting | P5-P5 | 384 | Zone B (Coupling & Cascading Methodology) |
| `4.` | 4. Results | P5-P5 | 0 | Zone B (Coupling & Cascading Methodology) |
| `4.1.` | 4.1. Power distribution system fault analysis | P5-P6 | 519 | Zone B (Coupling & Cascading Methodology) |
| `4.2.` | 4.2. Water distribution system fault analysis | P6-P7 | 681 | Zone B (Coupling & Cascading Methodology) |
| `4.3.` | 4.3. Vulnerability assessment | P7-P8 | 453 | Zone B (Coupling & Cascading Methodology) |
| `5.` | 5. Discussion | P8-P10 | 703 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `6.` | 6. Conclusions | P10-P11 | 679 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `Appendix` | Appendix | P11-P11 | 127 | Stripped_Noise (References/Ack) |
| `CRediT authorship contribution statement` | CRediT authorship contribution statement | P11-P13 | 580 | Stripped_Noise (References/Ack) |
| `Data availability` | Data availability | P13-P13 | 9 | Stripped_Noise (References/Ack) |
| `References` | References | P13-P13 | 1227 | Stripped_Noise (References/Ack) |

**剥离项：** 1. Introduction (Early Background Review Part)（885词，Introduction Background Literature Review）；Appendix（127词，References / Acknowledgments / Back-matter）；CRediT authorship contribution statement（580词，References / Acknowledgments / Back-matter）；Data availability（9词，References / Acknowledgments / Back-matter）；References（1227词，References / Acknowledgments / Back-matter）

### B002-PDF-03 / Cleaned_ID 36：Optimal Coordinated Operation of Interdependent Power and Water Distribution Systems

- PDF文件：`173_Optimal_Coordinated_Operation_of_Interdependent_Power_and_Water_Distribution_Systems.pdf`；页数：11；解析题名：Optimal Coordinated Operation of Interdependent Power and Water Distribution Systems；期刊/年份：IEEE Transactions on Smart Grid;2020;11;6;10.1109/TSG.2020.3000173 (2025)

| 章节号 | 章节标题 | 页码 | 词数 | 区域 |
|---|---|---|---:|---|
| `I.` | I. INTRODUCTION | P2-P3 | 1350 | Zone A (Kept Core Contribution) + Stripped (Early Intro) |
| `C.` | C. Contribution and Paper Structure | P3-P4 | 312 | Zone B (Coupling & Cascading Methodology) |
| `D.` | D. Notation | P4-P4 | 376 | Zone B (Coupling & Cascading Methodology) |
| `II.` | II. FLEXIBLE POWER-WATER FLOW SCHEDULING MODEL | P4-P6 | 2209 | Zone B (Coupling & Cascading Methodology) |
| `III.` | III. SOLUTION APPROACH | P6-P7 | 897 | Zone B (Coupling & Cascading Methodology) |
| `IV.` | IV. SIMULATION RESULTS | P7-P10 | 2204 | Zone B (Coupling & Cascading Methodology) |
| `V.` | V. CONCLUSION | P10-P11 | 1624 | Zone D (Case Setup, Social/Human Context & Limitations) |

**剥离项：** I. INTRODUCTION (Early Background Review Part)（1090词，Introduction Background Literature Review）

### B002-PDF-04 / Cleaned_ID 38：Risk-averse restoration of coupled power and water systems with small pumped-hydro storage and stochastic rooftop renewables

- PDF文件：`56_Risk-averse restoration of coupled power and water systems with small pumped-hydro storage and stochastic rooftop renewables.pdf`；页数：14；解析题名：Risk-averse restoration of coupled power and water systems with small pumped-hydro storage and stochastic rooftop renewables；期刊/年份：Applied Energy (2023)

| 章节号 | 章节标题 | 页码 | 词数 | 区域 |
|---|---|---|---:|---|
| `I` | I N F O | P1-P2 | 516 | Zone B (Coupling & Cascading Methodology) |
| `1.` | 1. Introduction | P2-P2 | 0 | Zone A (Meta, Abstract & Core Contribution) |
| `1.1.` | 1.1. Background and literature review | P2-P3 | 1760 | Zone B (Coupling & Cascading Methodology) |
| `1.2.` | 1.2. Contributions | P3-P4 | 271 | Zone B (Coupling & Cascading Methodology) |
| `2.` | 2. Interdependencies formulation | P4-P4 | 0 | Zone B (Coupling & Cascading Methodology) |
| `2.1.` | 2.1. Overview | P4-P4 | 285 | Zone B (Coupling & Cascading Methodology) |
| `2.2.` | 2.2. Production phase: | P4-P4 | 0 | Zone B (Coupling & Cascading Methodology) |
| `2.2.1.` | 2.2.1. Desalination plant | P4-P4 | 113 | Zone B (Coupling & Cascading Methodology) |
| `2.2.2.` | 2.2.2. Water treatment | P4-P4 | 50 | Zone B (Coupling & Cascading Methodology) |
| `2.3.` | 2.3. Distribution phase: | P4-P4 | 0 | Zone B (Coupling & Cascading Methodology) |
| `2.3.1.` | 2.3.1. Small pumped-hydro storage | P4-P4 | 292 | Zone B (Coupling & Cascading Methodology) |
| `2.3.2.` | 2.3.2. Pump station | P4-P4 | 86 | Zone B (Coupling & Cascading Methodology) |
| `2.3.3.` | 2.3.3. Water tower | P4-P4 | 47 | Zone B (Coupling & Cascading Methodology) |
| `2.4.` | 2.4. Consumption phase: | P5-P5 | 0 | Zone B (Coupling & Cascading Methodology) |
| `2.4.1.` | 2.4.1. Water booster pressure system | P5-P5 | 284 | Zone B (Coupling & Cascading Methodology) |
| `2.4.2.` | 2.4.2. Power & water nexus loads | P5-P5 | 231 | Zone B (Coupling & Cascading Methodology) |
| `3.` | 3. Two-stage risk-averse stochastic restoration for CPW system | P5-P5 | 28 | Zone B (Coupling & Cascading Methodology) |
| `3.1.` | 3.1. Performance metric | P5-P6 | 300 | Zone B (Coupling & Cascading Methodology) |
| `3.2.` | 3.2. Risk-averse objective | P6-P6 | 198 | Zone B (Coupling & Cascading Methodology) |
| `3.3.` | 3.3. Network reconfiguration and fuel pre-allocation | P6-P6 | 208 | Zone B (Coupling & Cascading Methodology) |
| `3.4.` | 3.4. WDS operation model | P6-P7 | 448 | Zone B (Coupling & Cascading Methodology) |
| `3.5.` | 3.5. PDS operation model | P7-P7 | 528 | Zone B (Coupling & Cascading Methodology) |
| `4.` | 4. Solution method | P7-P7 | 0 | Zone B (Coupling & Cascading Methodology) |
| `4.1.` | 4.1. Scenario-based stochastic restoration model | P7-P7 | 0 | Zone B (Coupling & Cascading Methodology) |
| `4.1.1.` | 4.1.1. Uncertainty modeling | P7-P7 | 130 | Zone B (Coupling & Cascading Methodology) |
| `4.1.2.` | 4.1.2. Scenario generation and reduction | P7-P7 | 63 | Zone B (Coupling & Cascading Methodology) |
| `4.2.` | 4.2. Linearization and convexification | P7-P7 | 39 | Zone B (Coupling & Cascading Methodology) |
| `4.2.1.` | 4.2.1. Symmetric approximation | P7-P7 | 275 | Zone B (Coupling & Cascading Methodology) |
| `4.2.2.` | 4.2.2. Big-M method | P7-P8 | 167 | Zone B (Coupling & Cascading Methodology) |
| `4.2.3.` | 4.2.3. McCormick envelopes | P8-P8 | 234 | Zone B (Coupling & Cascading Methodology) |
| `4.2.4.` | 4.2.4. Convex relaxation | P8-P8 | 72 | Zone B (Coupling & Cascading Methodology) |
| `4.2.5.` | 4.2.5. Piece-wise linearization | P8-P8 | 169 | Zone B (Coupling & Cascading Methodology) |
| `5.` | 5. Case study and numerical results | P8-P8 | 0 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `5.1.` | 5.1. Case study | P8-P9 | 731 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `5.2.` | 5.2. Numerical results | P10-P10 | 594 | Zone B (Coupling & Cascading Methodology) |
| `5.3.` | 5.3. Method comparison | P10-P13 | 672 | Zone B (Coupling & Cascading Methodology) |
| `6.` | 6. Concluding remarks | P13-P13 | 288 | Zone B (Coupling & Cascading Methodology) |
| `CRediT authorship contribution statement` | CRediT authorship contribution statement | P13-P13 | 40 | Stripped_Noise (References/Ack) |
| `Declaration of competing interest` | Declaration of competing interest | P13-P13 | 29 | Stripped_Noise (References/Ack) |
| `Data availability` | Data availability | P13-P13 | 18 | Stripped_Noise (References/Ack) |
| `Acknowledgments` | Acknowledgments | P13-P13 | 51 | Stripped_Noise (References/Ack) |
| `References` | References | P13-P14 | 1611 | Stripped_Noise (References/Ack) |

**剥离项：** CRediT authorship contribution statement（40词，References / Acknowledgments / Back-matter）；Declaration of competing interest（29词，References / Acknowledgments / Back-matter）；Data availability（18词，References / Acknowledgments / Back-matter）；Acknowledgments（51词，References / Acknowledgments / Back-matter）；References（1611词，References / Acknowledgments / Back-matter）

### B002-PDF-05 / Cleaned_ID 39：Worst-case vulnerability assessment and mitigation model of urban utility tunnels

- PDF文件：`1741_Worst-case vulnerability assessment and mitigation model of urban utility tunnels.pdf`；页数：11；解析题名：Worst-case vulnerability assessment and mitigation model of urban utility tunnels；期刊/年份：Reliability Engineering and System Safety (2020)

| 章节号 | 章节标题 | 页码 | 词数 | 区域 |
|---|---|---|---:|---|
| `2.` | 2. Problem formulation | P3-P5 | 3158 | Zone B (Coupling & Cascading Methodology) |
| `3.` | 3. Solution algorithm | P5-P7 | 1543 | Zone B (Coupling & Cascading Methodology) |
| `4.` | 4. Case study | P7-P10 | 2986 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `5.` | 5. Conclusion and future work | P10-P11 | 692 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `Acknowledgments` | Acknowledgments | P11-P11 | 58 | Stripped_Noise (References/Ack) |
| `References` | References | P11-P11 | 1295 | Stripped_Noise (References/Ack) |

**剥离项：** Acknowledgments（58词，References / Acknowledgments / Back-matter）；References（1295词，References / Acknowledgments / Back-matter）

### B002-PDF-06 / Cleaned_ID 46：A mathematical framework to optimize resilience of interdependent critical infrastructure systems under spatially localized attacks

- PDF文件：`3875_A mathematical framework to optimize resilience of interdependent critical infrastructure systems under spatially localized attacks.pdf`；页数：13；解析题名：A mathematical framework to optimize resilience of interdependent critical infrastructure systems under spatially localized attacks；期刊/年份：European Journal of Operational Research (2017)

| 章节号 | 章节标题 | 页码 | 词数 | 区域 |
|---|---|---|---:|---|
| `2.` | 2. Model for resilience optimization of interdependent CISs | P3-P5 | 3576 | Zone B (Coupling & Cascading Methodology) |
| `3.` | 3. Solution algorithm | P5-P6 | 837 | Zone B (Coupling & Cascading Methodology) |
| `1` | 1 Denote the set of all system components by I , Given the failure of a set A of | P6-P7 | 2046 | Zone A (Kept Core Contribution) + Stripped (Early Intro) |
| `4.` | 4. Case study | P7-P9 | 1655 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `4.2.` | 4.2. Importance of interdependencies | P9-P11 | 1252 | Zone B (Coupling & Cascading Methodology) |
| `5.` | 5. Conclusions | P11-P12 | 745 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `Acknowledgments` | Acknowledgments | P12-P12 | 63 | Stripped_Noise (References/Ack) |
| `References` | References | P12-P13 | 1728 | Stripped_Noise (References/Ack) |

**剥离项：** 1 Denote the set of all system components by I , Given the failure of a set A of (Early Background Review Part)（2334词，Introduction Background Literature Review）；Acknowledgments（63词，References / Acknowledgments / Back-matter）；References（1728词，References / Acknowledgments / Back-matter）

### B002-PDF-07 / Cleaned_ID 54：A nexus approach to infrastructure resilience planning under uncertainty

- PDF文件：`450_A nexus approach to infrastructure resilience planning under uncertainty.pdf`；页数：14；解析题名：A nexus approach to infrastructure resilience planning under uncertainty；期刊/年份：Reliability Engineering and System Safety (2023)

| 章节号 | 章节标题 | 页码 | 词数 | 区域 |
|---|---|---|---:|---|
| `1.` | 1. Developing a framework for identifying optimal hardening de- | P2-P2 | 10 | Zone B (Coupling & Cascading Methodology) |
| `2.` | 2. Exploring the relationship between power and water infrastruc- | P2-P2 | 7 | Zone B (Coupling & Cascading Methodology) |
| `3.` | 3. Characterizing the uncertainty in natural disaster realization and | P2-P2 | 12 | Zone B (Coupling & Cascading Methodology) |
| `4.` | 4. Applying our framework to a detailed, empirically grounded | P2-P2 | 283 | Zone B (Coupling & Cascading Methodology) |
| `2.` | 2. Literature review | P2-P3 | 1116 | Zone B (Coupling & Cascading Methodology) |
| `2.1.` | 2.1. Treatment of uncertainty | P3-P3 | 688 | Zone B (Coupling & Cascading Methodology) |
| `2.2.` | 2.2. Decision objectives | P3-P4 | 365 | Zone B (Coupling & Cascading Methodology) |
| `2.3.` | 2.3. Temporal resolution and planning horizon | P4-P4 | 509 | Zone B (Coupling & Cascading Methodology) |
| `2.4.` | 2.4. Case study selection | P4-P4 | 274 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `3.` | 3. Formulation | P4-P6 | 1952 | Zone B (Coupling & Cascading Methodology) |
| `4.` | 4. Case study | P6-P6 | 232 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `4.1.` | 4.1. Guayama power and water networks | P7-P8 | 698 | Zone B (Coupling & Cascading Methodology) |
| `4.2.` | 4.2. Hurricane scenario generation | P8-P9 | 1172 | Zone B (Coupling & Cascading Methodology) |
| `5.` | 5. Results | P9-P9 | 277 | Zone B (Coupling & Cascading Methodology) |
| `5.1.` | 5.1. Base case | P9-P10 | 1282 | Zone B (Coupling & Cascading Methodology) |
| `5.2.` | 5.2. Service threshold | P10-P11 | 385 | Zone B (Coupling & Cascading Methodology) |
| `5.3.` | 5.3. Repair costs | P11-P11 | 310 | Zone B (Coupling & Cascading Methodology) |
| `5.4.` | 5.4. Power-water prioritization | P11-P12 | 334 | Zone B (Coupling & Cascading Methodology) |
| `6.` | 6. Conclusions | P12-P12 | 248 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `1.` | 1. The decisions prescribed by our model favor hardening the | P12-P12 | 179 | Zone B (Coupling & Cascading Methodology) |
| `3.` | 3. In the base parametrisation, we find that hedging with respect to | P12-P12 | 69 | Zone B (Coupling & Cascading Methodology) |
| `4.` | 4. A tighter service level requirement in the planning stage im- | P12-P12 | 30 | Zone B (Coupling & Cascading Methodology) |
| `5.` | 5. Significantly higher and significantly lower repair costs than | P12-P12 | 36 | Zone B (Coupling & Cascading Methodology) |
| `6.` | 6. The relative prioritization of water versus power service im- | P12-P12 | 325 | Zone B (Coupling & Cascading Methodology) |
| `CRediT authorship contribution statement` | CRediT authorship contribution statement | P12-P12 | 83 | Stripped_Noise (References/Ack) |
| `Declaration of competing interest` | Declaration of competing interest | P12-P12 | 29 | Stripped_Noise (References/Ack) |
| `Data availability` | Data availability | P12-P12 | 9 | Stripped_Noise (References/Ack) |
| `Acknowledgments` | Acknowledgments | P13-P13 | 145 | Stripped_Noise (References/Ack) |
| `References` | References | P13-P14 | 1874 | Stripped_Noise (References/Ack) |

**剥离项：** CRediT authorship contribution statement（83词，References / Acknowledgments / Back-matter）；Declaration of competing interest（29词，References / Acknowledgments / Back-matter）；Data availability（9词，References / Acknowledgments / Back-matter）；Acknowledgments（145词，References / Acknowledgments / Back-matter）；References（1874词，References / Acknowledgments / Back-matter）

### B002-PDF-08 / Cleaned_ID 58：High level architecture-based framework for modeling interdependent critical infrastructure systems

- PDF文件：`4144.pdf`；页数：24；解析题名：High level architecture-based framework for modeling interdependent critical infrastructure systems；期刊/年份：Simulation Modelling Practice and Theory (2022)

| 章节号 | 章节标题 | 页码 | 词数 | 区域 |
|---|---|---|---:|---|
| `1.` | 1. Introduction | P1-P1 | 178 | Zone A (Meta, Abstract & Core Contribution) |
| `2.` | 2. Related work | P2-P2 | 0 | Stripped_Noise (Related Work Review) |
| `2.1.` | 2.1. State of the art on modeling interdependent CISs | P2-P2 | 1009 | Zone B (Coupling & Cascading Methodology) |
| `2.2.` | 2.2. HLA-based modeling of interdependent CISs | P3-P3 | 1070 | Zone B (Coupling & Cascading Methodology) |
| `3.` | 3. Methodology | P4-P4 | 0 | Zone B (Coupling & Cascading Methodology) |
| `3.1.` | 3.1. Interdependent CISs federation architecture | P4-P5 | 780 | Zone B (Coupling & Cascading Methodology) |
| `3.1.1.` | 3.1.1. The application layer | P5-P5 | 230 | Zone B (Coupling & Cascading Methodology) |
| `3.1.2.` | 3.1.2. The organizational layer | P5-P7 | 1093 | Zone B (Coupling & Cascading Methodology) |
| `3.1.3.` | 3.1.3. The communication layer | P7-P7 | 66 | Zone B (Coupling & Cascading Methodology) |
| `3.2.` | 3.2. CISs federation development process | P8-P9 | 861 | Zone B (Coupling & Cascading Methodology) |
| `3.2.1.` | 3.2.1. Objectives development | P9-P9 | 95 | Zone B (Coupling & Cascading Methodology) |
| `3.2.2.` | 3.2.2. Conceptual design | P9-P10 | 183 | Zone B (Coupling & Cascading Methodology) |
| `3.2.3.` | 3.2.3. Federation design | P11-P11 | 66 | Zone B (Coupling & Cascading Methodology) |
| `3.2.4.` | 3.2.4. Federation implementation | P11-P11 | 110 | Zone B (Coupling & Cascading Methodology) |
| `4.` | 4. Case study | P12-P12 | 0 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `4.1.` | 4.1. Case descriptions | P12-P12 | 211 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `4.1.1.` | 4.1.1. Power supply system | P12-P12 | 147 | Zone B (Coupling & Cascading Methodology) |
| `4.1.2.` | 4.1.2. Water supply system | P12-P12 | 87 | Zone B (Coupling & Cascading Methodology) |
| `4.1.3.` | 4.1.3. System interdependencies | P12-P12 | 98 | Zone B (Coupling & Cascading Methodology) |
| `4.2.` | 4.2. Model development | P13-P13 | 270 | Zone B (Coupling & Cascading Methodology) |
| `4.2.1.` | 4.2.1. Objectives development | P13-P13 | 69 | Zone B (Coupling & Cascading Methodology) |
| `4.2.2.` | 4.2.2. Conceptual design | P13-P14 | 453 | Zone B (Coupling & Cascading Methodology) |
| `4.2.3.` | 4.2.3. Federation design | P14-P14 | 283 | Zone B (Coupling & Cascading Methodology) |
| `4.2.4.` | 4.2.4. Federation implementation | P14-P15 | 327 | Zone B (Coupling & Cascading Methodology) |
| `4.3.` | 4.3. Model verification and validation | P16-P16 | 580 | Zone B (Coupling & Cascading Methodology) |
| `5.` | 5. Simulation results | P17-P17 | 0 | Zone B (Coupling & Cascading Methodology) |
| `5.1.` | 5.1. Scenario one | P17-P18 | 612 | Zone B (Coupling & Cascading Methodology) |
| `5.2.` | 5.2. Scenario two | P19-P20 | 1049 | Zone B (Coupling & Cascading Methodology) |
| `6.` | 6. Discussions | P20-P21 | 1846 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `7.` | 7. Conclusions | P22-P22 | 0 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `Acknowledgments` | Acknowledgments | P22-P22 | 0 | Stripped_Noise (References/Ack) |
| `References` | References | P22-P24 | 3505 | Stripped_Noise (References/Ack) |

**剥离项：** 2. Related work（0词，Related Work (Literature Review of Other Papers)）；Acknowledgments（0词，References / Acknowledgments / Back-matter）；References（3505词，References / Acknowledgments / Back-matter）

### B002-PDF-09 / Cleaned_ID 59：Collaborative decision making for natural disaster recovery of interdependent infrastructure systems

- PDF文件：`4131_Collaborative decision making for natural disaster recovery of interdependent infrastructure systems.pdf`；页数：20；解析题名：Collaborative decision making for natural disaster recovery of interdependent infrastructure systems；期刊/年份：Reliability Engineering and System Safety (2026)

| 章节号 | 章节标题 | 页码 | 词数 | 区域 |
|---|---|---|---:|---|
| `1.` | 1. Introduction | P1-P2 | 688 | Zone A (Kept Core Contribution) + Stripped (Early Intro) |
| `2.` | 2. Literature review | P2-P2 | 122 | Zone B (Coupling & Cascading Methodology) |
| `2.1.` | 2.1. Recovery planning of interdependent CISs | P2-P3 | 708 | Zone B (Coupling & Cascading Methodology) |
| `2.2.` | 2.2. Multi-stakeholder collaboration in the recovery planning of CISs | P3-P3 | 260 | Zone B (Coupling & Cascading Methodology) |
| `2.3.` | 2.3. Resilience measurement and improvement of interdependent CISs | P3-P3 | 324 | Zone B (Coupling & Cascading Methodology) |
| `3.` | 3. Proposed collaborative decision framework | P3-P3 | 49 | Zone B (Coupling & Cascading Methodology) |
| `3.1.` | 3.1. Research design and methodology | P3-P5 | 589 | Zone B (Coupling & Cascading Methodology) |
| `3.2.` | 3.2. Framework implementation | P5-P5 | 0 | Zone B (Coupling & Cascading Methodology) |
| `3.2.1.` | 3.2.1. System representation and modeling | P5-P5 | 131 | Zone B (Coupling & Cascading Methodology) |
| `3.2.2.` | 3.2.2. Local recovery planning | P5-P5 | 145 | Zone B (Coupling & Cascading Methodology) |
| `3.2.3.` | 3.2.3. Dependency modeling | P5-P5 | 83 | Zone B (Coupling & Cascading Methodology) |
| `3.2.4.` | 3.2.4. Coalitions and value function formulation | P5-P5 | 285 | Zone B (Coupling & Cascading Methodology) |
| `3.2.5.` | 3.2.5. Shapley-value allocation | P5-P5 | 202 | Zone B (Coupling & Cascading Methodology) |
| `4.` | 4. Case study | P6-P7 | 128 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `4.1.` | 4.1. Background on the Wenchuan earthquake disaster of May 2008 | P7-P8 | 465 | Zone B (Coupling & Cascading Methodology) |
| `4.2.` | 4.2. Framework implementation for the Mianzhu case | P8-P9 | 628 | Zone B (Coupling & Cascading Methodology) |
| `1.` | 1. Local action selection: each CIS module submits its local preferred | P9-P9 | 16 | Zone B (Coupling & Cascading Methodology) |
| `2.` | 2. Dependency check: the supervisory agent computes prerequisites | P9-P9 | 16 | Zone B (Coupling & Cascading Methodology) |
| `3.` | 3. Feasible coalition generation: the supervisory agent enumerates | P9-P9 | 13 | Zone B (Coupling & Cascading Methodology) |
| `4.` | 4. Coalition evaluation: the supervisory agent computes v(C) for using | P9-P9 | 66 | Zone B (Coupling & Cascading Methodology) |
| `4.3.` | 4.3. Implementation of benchmark models | P9-P10 | 809 | Zone B (Coupling & Cascading Methodology) |
| `4.4.` | 4.4. Evaluation metrics | P10-P11 | 540 | Zone B (Coupling & Cascading Methodology) |
| `5.` | 5. Results | P11-P11 | 127 | Zone B (Coupling & Cascading Methodology) |
| `5.1.` | 5.1. Analysis of the initial restoration plan of each CIS | P11-P12 | 315 | Zone B (Coupling & Cascading Methodology) |
| `5.2.` | 5.2. Comparative analysis of recovery strategies | P12-P14 | 961 | Zone B (Coupling & Cascading Methodology) |
| `5.3.` | 5.3. Analysis of resilience metrics | P14-P15 | 140 | Zone B (Coupling & Cascading Methodology) |
| `5.3.1.` | 5.3.1. Conventional resilience (AUC-based) and PoA | P15-P15 | 565 | Zone B (Coupling & Cascading Methodology) |
| `5.4.` | 5.4. Analysis of computational resources | P15-P15 | 313 | Zone B (Coupling & Cascading Methodology) |
| `6.` | 6. Discussion | P15-P15 | 76 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `6.1.` | 6.1. Comparative assessment of centralized, decentralized and hybrid | P15-P16 | 601 | Zone B (Coupling & Cascading Methodology) |
| `6.2.` | 6.2. Implications for research in the field of interdependent CISs recovery | P16-P16 | 337 | Zone B (Coupling & Cascading Methodology) |
| `6.3.` | 6.3. Implications for management practices | P16-P17 | 515 | Zone B (Coupling & Cascading Methodology) |
| `7.` | 7. Conclusion | P17-P17 | 486 | Zone D (Case Setup, Social/Human Context & Limitations) |
| `CRediT authorship contribution statement` | CRediT authorship contribution statement | P17-P17 | 47 | Stripped_Noise (References/Ack) |
| `Declaration of competing interest` | Declaration of competing interest | P17-P17 | 28 | Stripped_Noise (References/Ack) |
| `Acknowledgments` | Acknowledgments | P17-P18 | 101 | Stripped_Noise (References/Ack) |
| `Data availability` | Data availability | P18-P18 | 9 | Stripped_Noise (References/Ack) |
| `References` | References | P18-P20 | 2159 | Stripped_Noise (References/Ack) |

**剥离项：** 1. Introduction (Early Background Review Part)（446词，Introduction Background Literature Review）；CRediT authorship contribution statement（47词，References / Acknowledgments / Back-matter）；Declaration of competing interest（28词，References / Acknowledgments / Back-matter）；Acknowledgments（101词，References / Acknowledgments / Back-matter）；Data availability（9词，References / Acknowledgments / Back-matter）；References（2159词，References / Acknowledgments / Back-matter）

### B002-PDF-10 / Cleaned_ID 60：Managing Water-Energy-Carbon Nexus for Urban Areas With Ambiguous Moment Information

- PDF文件：`2373_Managing_Water-Energy-Carbon_Nexus_for_Urban_Areas_With_Ambiguous_Moment_Information.pdf`；页数：15；解析题名：Managing Water-Energy-Carbon Nexus for Urban Areas With Ambiguous Moment Information；期刊/年份：IEEE Transactions on Power Systems;2023;38;5;10.1109/TPWRS.2022.3214189 (2025)

| 章节号 | 章节标题 | 页码 | 词数 | 区域 |
|---|---|---|---:|---|
| `C.` | C. Variables | P2-P2 | 209 | Zone B (Coupling & Cascading Methodology) |
| `I.` | I. INTRODUCTION | P2-P4 | 1985 | Zone A (Kept Core Contribution) + Stripped (Early Intro) |
| `II.` | II. PROBLEM FORMULATION | P4-P6 | 1803 | Zone B (Coupling & Cascading Methodology) |
| `C.` | C. Real-Time Operation | P6-P6 | 191 | Zone B (Coupling & Cascading Methodology) |
| `D.` | D. Objective Function | P6-P7 | 200 | Zone B (Coupling & Cascading Methodology) |
| `III.` | III. SOLUTION METHOD | P7-P8 | 701 | Zone B (Coupling & Cascading Methodology) |
| `IV.` | IV. CASE STUDIES | P8-P11 | 1555 | Zone B (Coupling & Cascading Methodology) |
| `C.` | C. Economic Performance of the Nexus System | P11-P11 | 224 | Zone B (Coupling & Cascading Methodology) |
| `D.` | D. Scalability Analysis | P11-P12 | 437 | Zone B (Coupling & Cascading Methodology) |
| `V.` | V. CONCLUDING REMARKS | P12-P15 | 3119 | Zone B (Coupling & Cascading Methodology) |

**剥离项：** I. INTRODUCTION (Early Background Review Part)（1668词，Introduction Background Literature Review）

