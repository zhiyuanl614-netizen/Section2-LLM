# -*- coding: utf-8 -*-
"""
Step 1: Academic PDF Two-Column Layout Reconstruction, Section Tree Parser & Four-Zone Targeted Slicer
Target: Chapter 2 - LLM-Driven Text Data Mining for Frontier Research Direction Identification
"""

import os
import re
import json
import pymupdf
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
import docx
from docx import Document
from docx.shared import Pt, Inches, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import qn, nsdecls

# Strict Section Heading Regex:
# Matches "1. Introduction", "2.2.1. Initial Trigger...", "Acknowledgments", "References", etc.
# Excludes decimal numbers in sentences like "0.02. The tolerance..."
HEADING_REGEX = re.compile(
    r'^(?:([1-9]\d*(?:\.[1-9]\d*)*)\.?\s+([A-Z][A-Za-z0-9\-\s,:()/&]+)|'
    r'(Acknowledgments?|References|Appendix|Declaration of competing interest|CRediT authorship contribution statement|Data availability))$'
)

BOILERPLATE_PATTERNS = [
    r'^Contents lists available at ScienceDirect$',
    r'^journal homepage:\s*www\.elsevier\.com',
    r'^Available online\s+\d+',
    r'^\*\s*Corresponding author',
    r'^E-mail address',
    r'^https?://doi\.org/',
    r'^\d{4}-\d{4}/©',
    r'^Received\s+\d+\s+[A-Za-z]+\s+\d{4}',
]

def clean_text_line(text):
    """Remove soft hyphens (\xad) and normalize whitespace."""
    text = re.sub(r'\xad\s*', '', text)
    text = re.sub(r'-\s+(?=[a-z])', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def is_boilerplate(text, y0, y1, page_height, pno):
    """Identify header, footer, copyright, and page-number boilerplate."""
    if y0 < 48.0 or y1 > page_height - 42.0:
        return True
    if pno == 0 and y0 > 662.0:
        return True
    for pat in BOILERPLATE_PATTERNS:
        if re.search(pat, text, re.IGNORECASE):
            return True
    return False

def is_valid_section_heading(line_text, max_size, is_bold, is_italic):
    """Determine if a line is a true section/subsection heading."""
    line_clean = line_text.strip()
    if len(line_clean) > 115 or len(line_clean) < 4:
        return False
    # Must not end with a period, semicolon, or comma
    if line_clean.endswith('.') or line_clean.endswith(',') or line_clean.endswith(';'):
        return False
    m = HEADING_REGEX.match(line_clean)
    if not m:
        return False
    # Check font style or numbering structure
    sec_num = m.group(1)
    sec_title = m.group(2)
    unnumbered = m.group(3)
    if unnumbered:
        return is_bold
    if sec_num:
        # Ensure it's not a table/figure line or sentence fragment
        if re.search(r'\b(is|are|was|were|can|will|should|must|has|have)\b', sec_title.lower()):
            return False
        return True
    return False

def parse_pdf_structure(pdf_path, doc_id):
    """
    Parse a two-column academic PDF into metadata, full hierarchical section tree,
    and Four-Zone Targeted Slices (Zone A, Zone B, Zone C, Zone D) + Stripped Noise stats.
    """
    doc = pymupdf.open(pdf_path)
    meta_raw = doc.metadata or {}
    total_pages = len(doc)

    # Extract DOI and Journal from metadata subject
    subj = meta_raw.get("subject", "")
    doi_match = re.search(r'10\.\d{4,9}/[-._;()/:A-Za-z0-9]+', subj)
    doi = doi_match.group(0) if doi_match else ""
    year_match = re.search(r'\((20\d\d)\)', subj)
    pub_year = int(year_match.group(1)) if year_match else 2025
    journal = subj.split(',')[0].strip() if ',' in subj else subj

    # Extract Abstract and Keywords from Page 1
    page1 = doc[0]
    p1_blocks = page1.get_text("blocks")
    abstract_text = ""
    keywords_text = meta_raw.get("keywords", "")
    authors_line = meta_raw.get("author", "")

    for b in p1_blocks:
        if b[6] != 0:
            continue
        bx0, by0, bx1, by1, btxt = b[0], b[1], b[2], b[3], clean_text_line(b[4])
        if 200 <= by0 <= 224 and bx0 < 100 and len(btxt) < 150:
            authors_line = btxt
        if by0 >= 270 and by1 <= 450 and bx0 >= 180:
            if btxt.upper() != "A B S T R A C T" and btxt.upper() != "ABSTRACT":
                abstract_text += (" " + btxt if abstract_text else btxt)
        if by0 >= 270 and by1 <= 380 and bx0 < 150 and "keywords" in btxt.lower():
            kw_clean = re.sub(r'^keywords:\s*', '', btxt, flags=re.IGNORECASE)
            if kw_clean:
                keywords_text = kw_clean

    # Now reconstruct reading-order lines across all pages (starting from 1. Introduction)
    ordered_items = []  # list of dicts: {page, text, is_heading, sec_num, sec_title}

    for pno in range(total_pages):
        page = doc[pno]
        pw, ph = page.rect.width, page.rect.height
        mid_x = pw / 2.0
        blocks = page.get_text("dict")["blocks"]

        left_col_blocks = []
        right_col_blocks = []
        spanning_blocks = []

        for b in blocks:
            if b.get("type") != 0:
                continue
            bx0, by0, bx1, by1 = b["bbox"]
            # Skip page 1 top region before 1. Introduction (y0 < 455)
            if pno == 0 and by0 < 455.0:
                continue

            # Extract lines inside block
            block_lines = []
            for l in b["lines"]:
                ltxt = clean_text_line("".join(s["text"] for s in l["spans"]))
                if not ltxt:
                    continue
                if is_boilerplate(ltxt, l["bbox"][1], l["bbox"][3], ph, pno):
                    continue
                max_sz = max((s["size"] for s in l["spans"]), default=0)
                is_bd = any("bold" in s["font"].lower() or "medi" in s["font"].lower() or (s["flags"] & 16) for s in l["spans"])
                is_it = any("ital" in s["font"].lower() or "obli" in s["font"].lower() or (s["flags"] & 2) for s in l["spans"])
                is_hd = is_valid_section_heading(ltxt, max_sz, is_bd, is_it)
                block_lines.append({
                    "page": pno + 1,
                    "y0": l["bbox"][1],
                    "x0": l["bbox"][0],
                    "text": ltxt,
                    "is_heading": is_hd
                })

            if not block_lines:
                continue

            if bx1 <= mid_x + 15:
                left_col_blocks.append((by0, block_lines))
            elif bx0 >= mid_x - 15:
                right_col_blocks.append((by0, block_lines))
            else:
                spanning_blocks.append((by0, block_lines))

        left_col_blocks.sort(key=lambda x: x[0])
        right_col_blocks.sort(key=lambda x: x[0])
        spanning_blocks.sort(key=lambda x: x[0])

        # Standard two-column academic order: left column top-to-bottom, right column top-to-bottom, then spanning captions
        for _, blines in left_col_blocks + right_col_blocks + spanning_blocks:
            ordered_items.extend(blines)

    # Group lines into hierarchical sections
    sections = []
    cur_sec = {
        "sec_id": "0",
        "sec_title": "Preamble",
        "start_page": 1,
        "end_page": 1,
        "lines": []
    }

    for item in ordered_items:
        if item["is_heading"]:
            if cur_sec["lines"] or cur_sec["sec_id"] != "0":
                sections.append(cur_sec)
            m = HEADING_REGEX.match(item["text"])
            if m and m.group(1):
                s_id = m.group(1)
                s_title = m.group(2).strip()
            else:
                s_id = item["text"].strip()
                s_title = item["text"].strip()
            cur_sec = {
                "sec_id": s_id,
                "sec_title": s_title,
                "full_heading": item["text"],
                "start_page": item["page"],
                "end_page": item["page"],
                "lines": []
            }
        else:
            cur_sec["end_page"] = max(cur_sec["end_page"], item["page"])
            cur_sec["lines"].append(item)

    if cur_sec["lines"] or cur_sec["sec_id"] != "0":
        sections.append(cur_sec)

    # Consolidate text with page markers [Page X] per section
    for s in sections:
        chunks = []
        last_p = None
        cur_buf = []
        for ln in s["lines"]:
            if ln["page"] != last_p:
                if cur_buf:
                    chunks.append(f"[Page {last_p}] " + " ".join(cur_buf))
                    cur_buf = []
                last_p = ln["page"]
            cur_buf.append(ln["text"])
        if cur_buf:
            chunks.append(f"[Page {last_p}] " + " ".join(cur_buf))
        s["full_text"] = "\n".join(chunks)
        s["word_count"] = len(re.findall(r'\b\w+\b', s["full_text"]))
        del s["lines"]

    # Map each section into Four Targeted Zones (Zone A, Zone B, Zone C, Zone D) or Stripped_Noise
    zone_a_parts = [
        f"[Document Metadata] Title: {meta_raw.get('title', '')} | Authors: {authors_line} | Journal: {journal} ({pub_year}) | DOI: {doi} | Keywords: {keywords_text}",
        f"[Page 1] [Abstract] {abstract_text}"
    ]
    zone_b_parts = []
    zone_c_parts = []
    zone_d_parts = []
    stripped_parts = []

    for s in sections:
        sid = s["sec_id"].lower()
        stitle = s["sec_title"].lower()
        full_h = s.get("full_heading", s["sec_title"])
        txt = s["full_text"]
        wc = s["word_count"]

        # 1. Strip References, Acknowledgments, Declaration, CRediT, Related Work (pure literature review)
        if any(k in sid or k in stitle for k in ["reference", "acknowledgment", "declaration", "credit", "data availability", "appendix"]):
            s["assigned_zone"] = "Stripped_Noise (References/Ack)"
            stripped_parts.append((full_h, wc, "References / Acknowledgments / Back-matter"))
            continue

        if stitle.startswith("related work") or sid.startswith("2") and ("related work" in stitle or "approaches for modeling" in stitle or "applications in modeling" in stitle):
            s["assigned_zone"] = "Stripped_Noise (Related Work Review)"
            stripped_parts.append((full_h, wc, "Related Work (Literature Review of Other Papers)"))
            continue

        # 2. Handle Introduction: Strip early background review, keep ONLY the last ~35% (Core Contributions & Paper Organization)
        if "introduction" in stitle or sid == "1":
            words = txt.split()
            if len(words) > 220:
                keep_words = words[-220:]
                stripped_wc = len(words) - 220
                kept_intro = " ".join(keep_words)
                zone_a_parts.append(f"[{full_h} - Core Contribution & Organization Excerpt (Pages {s['start_page']}-{s['end_page']})]\n{kept_intro}")
                stripped_parts.append((f"{full_h} (Early Background Review Part)", stripped_wc, "Introduction Background Literature Review"))
                s["assigned_zone"] = "Zone A (Kept Core Contribution) + Stripped (Early Intro)"
            else:
                zone_a_parts.append(f"[{full_h} (Pages {s['start_page']}-{s['end_page']})]\n{txt}")
                s["assigned_zone"] = "Zone A (Meta, Abstract & Core Contribution)"
            continue

        # 3. Zone B: System Topology, Coupling Mechanism, Cascading Model, Co-Simulation Model Development
        if any(k in stitle for k in [
            "methodology", "topology", "initial trigger", "functional failure", "coupled component",
            "cascading failure analysis of the wsn", "cascading failure analysis of the epn",
            "hla-based modeling", "simulation of cascading failure", "power supply system",
            "water supply system", "system interdependency", "case model development",
            "federate", "federation", "verification and validation"
        ]):
            zone_b_parts.append(f"### {full_h} (Pages {s['start_page']}-{s['end_page']})\n{txt}")
            s["assigned_zone"] = "Zone B (Coupling & Cascading Methodology)"
            continue

        # 4. Zone C: Functional Loss Metrics, Resilience Quantification, Sensitivity & Simulation Analyses
        if any(k in stitle for k in [
            "functional loss", "cascading failure simulation", "cascading failure results",
            "sensitivity analysis", "simulation results and analyses", "analysis context"
        ]):
            zone_c_parts.append(f"### {full_h} (Pages {s['start_page']}-{s['end_page']})\n{txt}")
            s["assigned_zone"] = "Zone C (Metrics, Simulation & Resilience Evaluation)"
            continue

        # 5. Zone D: Case Study Basic Info/Scenario, Discussion, Limitations & Conclusions
        if any(k in stitle for k in [
            "case study", "basic information", "case description", "scenario description",
            "discussion", "conclusion"
        ]):
            zone_d_parts.append(f"### {full_h} (Pages {s['start_page']}-{s['end_page']})\n{txt}")
            s["assigned_zone"] = "Zone D (Case Setup, Social/Human Context & Limitations)"
            continue

        # Fallback to Zone B
        zone_b_parts.append(f"### {full_h} (Pages {s['start_page']}-{s['end_page']})\n{txt}")
        s["assigned_zone"] = "Zone B (Coupling & Cascading Methodology)"

    zone_a_str = "\n\n".join(zone_a_parts)
    zone_b_str = "\n\n".join(zone_b_parts)
    zone_c_str = "\n\n".join(zone_c_parts)
    zone_d_str = "\n\n".join(zone_d_parts)

    wc_a = len(re.findall(r'\b\w+\b', zone_a_str))
    wc_b = len(re.findall(r'\b\w+\b', zone_b_str))
    wc_c = len(re.findall(r'\b\w+\b', zone_c_str))
    wc_d = len(re.findall(r'\b\w+\b', zone_d_str))
    wc_kept = wc_a + wc_b + wc_c + wc_d
    wc_stripped = sum(x[1] for x in stripped_parts)
    wc_total = wc_kept + wc_stripped
    noise_reduction_pct = round(wc_stripped * 100.0 / wc_total, 2) if wc_total > 0 else 0.0

    return {
        "doc_id": doc_id,
        "file_name": os.path.basename(pdf_path),
        "title": meta_raw.get("title", ""),
        "authors": authors_line,
        "journal": journal,
        "pub_year": pub_year,
        "doi": doi,
        "keywords": keywords_text,
        "total_pages": total_pages,
        "word_count_stats": {
            "raw_total_words": wc_total,
            "kept_targeted_words": wc_kept,
            "stripped_noise_words": wc_stripped,
            "noise_reduction_ratio_pct": noise_reduction_pct,
            "zone_a_words": wc_a,
            "zone_b_words": wc_b,
            "zone_c_words": wc_c,
            "zone_d_words": wc_d
        },
        "section_tree": [
            {
                "sec_id": s["sec_id"],
                "full_heading": s.get("full_heading", s["sec_title"]),
                "pages": f"P{s['start_page']}-P{s['end_page']}",
                "word_count": s["word_count"],
                "assigned_zone": s.get("assigned_zone", "")
            }
            for s in sections if s["sec_id"] != "0"
        ],
        "stripped_sections_detail": [
            {"heading": h, "word_count": w, "reason": r} for h, w, r in stripped_parts
        ],
        "targeted_zones": {
            "Zone_A_Meta_Abstract_Contribution": zone_a_str,
            "Zone_B_Coupling_And_Cascading_Model": zone_b_str,
            "Zone_C_Metrics_And_Simulation_Control": zone_c_str,
            "Zone_D_Case_Social_And_Limitations": zone_d_str
        }
    }

def generate_outputs(parsed_docs, out_dir):
    os.makedirs(out_dir, exist_ok=True)

    # 1. Save JSON Data Blocks
    json_path = os.path.join(out_dir, "step1_sliced_pdf_corpus.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(parsed_docs, f, ensure_ascii=False, indent=2)

    # 2. Save Markdown Preview of Targeted Slices
    md_path = os.path.join(out_dir, "step1_sliced_zones_preview.md")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# Step 1: 学术 PDF 章节结构树解析与四区靶向切片实验预览\n\n")
        for d in parsed_docs:
            st = d["word_count_stats"]
            f.write(f"## {d['doc_id']}: {d['title']}\n")
            f.write(f"- **源文件**: `{d['file_name']}` ({d['total_pages']} 页)\n")
            f.write(f"- **作者与期刊**: {d['authors']} | *{d['journal']}* ({d['pub_year']}) | DOI: `{d['doi']}`\n")
            f.write(f"- **靶向切片降噪统计**: 全文总词数 **{st['raw_total_words']}** 词 $\\rightarrow$ 靶向保留核心词数 **{st['kept_targeted_words']}** 词，自动剥离干扰噪声 **{st['stripped_noise_words']}** 词（**降噪率 {st['noise_reduction_ratio_pct']}%**）\n\n")
            f.write("### 识别的章节结构树与四区映射关系\n")
            f.write("| 章节编号 | 章节完整标题 | 所在页码 | 词数 | 映射目标区域 |\n")
            f.write("| :--- | :--- | :---: | :---: | :--- |\n")
            for s in d["section_tree"]:
                f.write(f"| `{s['sec_id']}` | {s['full_heading']} | {s['pages']} | {s['word_count']} | {s['assigned_zone']} |\n")
            f.write("\n---\n\n")

    # 3. Generate Excel Inspection Report
    wb = openpyxl.Workbook()
    ws_ov = wb.active
    ws_ov.title = "1_四区靶向切片降噪总览"

    header_fill = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
    zebra_fill = PatternFill(start_color="F9FAFC", end_color="F9FAFC", fill_type="solid")
    header_font = Font(name="微软雅黑", size=10, bold=True, color="FFFFFF")
    reg_font = Font(name="微软雅黑", size=9.5, color="262626")
    bold_font = Font(name="微软雅黑", size=9.5, bold=True, color="1F4E79")
    thin_border = Border(
        left=Side(style='thin', color='D9D9D9'), right=Side(style='thin', color='D9D9D9'),
        top=Side(style='thin', color='D9D9D9'), bottom=Side(style='thin', color='D9D9D9')
    )

    ov_headers = [
        "实验编号", "团队标识", "论文标题", "发表期刊与年份", "总页数",
        "全文总词数", "靶向保留词数", "剥离噪声词数", "Token降噪率(%)",
        "Zone A 词数\n(摘要与贡献)", "Zone B 词数\n(耦合与级联模型)",
        "Zone C 词数\n(指标与仿真分析)", "Zone D 词数\n(算例与局限性)"
    ]
    ws_ov.append(ov_headers)
    for c_idx in range(1, len(ov_headers) + 1):
        c = ws_ov.cell(row=1, column=c_idx)
        c.fill = header_fill
        c.font = header_font
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    for r_idx, d in enumerate(parsed_docs, start=2):
        st = d["word_count_stats"]
        team = "张明媛团队 (大连理工)" if "张明媛" in d["file_name"] else "李楠团队 (清华大学)"
        row_vals = [
            d["doc_id"], team, d["title"], f"{d['journal']} ({d['pub_year']})", d["total_pages"],
            st["raw_total_words"], st["kept_targeted_words"], st["stripped_noise_words"], st["noise_reduction_ratio_pct"],
            st["zone_a_words"], st["zone_b_words"], st["zone_c_words"], st["zone_d_words"]
        ]
        ws_ov.append(row_vals)
        for c_idx in range(1, len(ov_headers) + 1):
            cell = ws_ov.cell(row=r_idx, column=c_idx)
            cell.font = bold_font if c_idx in [1, 2, 9] else reg_font
            cell.border = thin_border
            cell.alignment = Alignment(horizontal="left" if c_idx in [3, 4] else "center", vertical="center", wrap_text=True)

    for c_idx, w in enumerate([12, 20, 48, 32, 10, 14, 14, 14, 16, 15, 16, 16, 15], start=1):
        ws_ov.column_dimensions[get_column_letter(c_idx)].width = w

    # Sheet 2: Detailed Section Tree Mapping
    ws_tree = wb.create_sheet(title="2_PDF章节结构树与四区映射明细")
    tree_headers = ["实验编号", "团队标识", "章节号", "识别出的完整章节标题", "PDF页码范围", "章节词数", "靶向分配区域 / 剥离原因"]
    ws_tree.append(tree_headers)
    for c_idx in range(1, len(tree_headers) + 1):
        c = ws_tree.cell(row=1, column=c_idx)
        c.fill = header_fill
        c.font = header_font
        c.alignment = Alignment(horizontal="center", vertical="center")

    row_cursor = 2
    for d in parsed_docs:
        team = "张明媛团队" if "张明媛" in d["file_name"] else "李楠团队"
        for s in d["section_tree"]:
            ws_tree.append([d["doc_id"], team, s["sec_id"], s["full_heading"], s["pages"], s["word_count"], s["assigned_zone"]])
            for c_idx in range(1, len(tree_headers) + 1):
                cell = ws_tree.cell(row=row_cursor, column=c_idx)
                cell.font = reg_font
                if "Stripped" in s["assigned_zone"]:
                    cell.font = Font(name="微软雅黑", size=9.5, italic=True, color="888888")
                elif row_cursor % 2 == 1:
                    cell.fill = zebra_fill
                cell.border = thin_border
                cell.alignment = Alignment(horizontal="center" if c_idx in [1, 2, 3, 5, 6] else "left", vertical="center")
            row_cursor += 1

    for c_idx, w in enumerate([12, 14, 12, 48, 14, 12, 38], start=1):
        ws_tree.column_dimensions[get_column_letter(c_idx)].width = w

    excel_path = os.path.join(out_dir, "Step1_PDF章节树解析与四区靶向切片实验报告.xlsx")
    wb.save(excel_path)

    # 4. Generate Word Inspection Report (.docx) for rich preview
    doc = Document()
    for section in doc.sections:
        section.page_width = Cm(21.0)
        section.page_height = Cm(29.7)
        section.top_margin = Cm(2.3)
        section.bottom_margin = Cm(2.3)
        section.left_margin = Cm(2.4)
        section.right_margin = Cm(2.4)

    p_t = doc.add_paragraph()
    p_t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r_t = p_t.add_run("第2章 Step 1 实验报告：学术 PDF 章节结构树解析与四区靶向切片核验")
    r_t.font.name = "Times New Roman"
    r_t._element.rPr.rFonts.set(qn('w:eastAsia'), "微软雅黑")
    r_t.font.size = Pt(15.5)
    r_t.bold = True
    r_t.font.color.rgb = RGBColor(20, 54, 93)

    p_sub = doc.add_paragraph()
    p_sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_sub.paragraph_format.space_after = Pt(10)
    r_sub = p_sub.add_run("实验对象：张明媛团队 (RESS, 2025) & 李楠团队 (Automation in Construction, 2022) 全文 PDF")
    r_sub.font.name = "Times New Roman"
    r_sub._element.rPr.rFonts.set(qn('w:eastAsia'), "微软雅黑")
    r_sub.font.size = Pt(10.5)
    r_sub.bold = True
    r_sub.font.color.rgb = RGBColor(89, 89, 89)

    # Add summary table in Word
    t_sum = doc.add_table(rows=len(parsed_docs) + 1, cols=7)
    t_sum.alignment = WD_TABLE_ALIGNMENT.CENTER
    sum_headers = ["样本编号与团队", "期刊与年份", "页数", "全文总词数", "靶向保留词数", "剥离干扰词数", "Token降噪率"]
    for i, h in enumerate(sum_headers):
        c = t_sum.rows[0].cells[i]
        tcPr = c._tc.get_or_add_tcPr()
        tcPr.append(parse_xml(f'<w:shd {nsdecls("w")} w:fill="1F4E79"/>'))
        p = c.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(h)
        r.font.name = "Times New Roman"
        r._element.rPr.rFonts.set(qn('w:eastAsia'), "微软雅黑")
        r.font.size = Pt(9.5)
        r.bold = True
        r.font.color.rgb = RGBColor(255, 255, 255)

    for idx, d in enumerate(parsed_docs, start=1):
        st = d["word_count_stats"]
        team = "PDF_01 张明媛团队" if "张明媛" in d["file_name"] else "PDF_02 李楠团队"
        vals = [
            team, f"{d['journal']} ({d['pub_year']})", str(d["total_pages"]),
            f"{st['raw_total_words']:,}", f"{st['kept_targeted_words']:,}",
            f"{st['stripped_noise_words']:,}", f"{st['noise_reduction_ratio_pct']}%"
        ]
        for c_i, v in enumerate(vals):
            cell = t_sum.rows[idx].cells[c_i]
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r = p.add_run(v)
            r.font.name = "Times New Roman"
            r._element.rPr.rFonts.set(qn('w:eastAsia'), "宋体")
            r.font.size = Pt(9.5)
            if c_i in [0, 6]:
                r.bold = True

    # Add per-document detailed section breakdown and Zone excerpts
    for d in parsed_docs:
        st = d["word_count_stats"]
        p_h = doc.add_paragraph()
        p_h.paragraph_format.space_before = Pt(14)
        p_h.paragraph_format.space_after = Pt(6)
        r_h = p_h.add_run(f"■ {d['doc_id']}：{d['title']} ({d['journal']}, {d['pub_year']})")
        r_h.font.name = "Times New Roman"
        r_h._element.rPr.rFonts.set(qn('w:eastAsia'), "微软雅黑")
        r_h.font.size = Pt(12)
        r_h.bold = True
        r_h.font.color.rgb = RGBColor(31, 78, 121)

        p_info = doc.add_paragraph()
        p_info.paragraph_format.space_after = Pt(4)
        r_info = p_info.add_run(
            f"• 四区词数分布：Zone A (摘要与核心贡献) = {st['zone_a_words']} 词 | "
            f"Zone B (耦合与级联机理) = {st['zone_b_words']} 词 | "
            f"Zone C (指标与仿真结果) = {st['zone_c_words']} 词 | "
            f"Zone D (算例背景、讨论与局限) = {st['zone_d_words']} 词。\n"
            f"• 自动剥离噪声项：" + "；".join(f"{x['heading']} ({x['word_count']}词)" for x in d["stripped_sections_detail"])
        )
        r_info.font.name = "Times New Roman"
        r_info._element.rPr.rFonts.set(qn('w:eastAsia'), "宋体")
        r_info.font.size = Pt(9.5)

        # Show key excerpts from Zone A, B, C, D to prove accurate two-column reconstruction & page anchoring
        zones_preview = [
            ("Zone A 切片采样（元数据、摘要与导言末段核心贡献）", d["targeted_zones"]["Zone_A_Meta_Abstract_Contribution"][:650] + " ..."),
            ("Zone B 切片采样（水-电耦合机理与级联模型章节，带页码锚点）", d["targeted_zones"]["Zone_B_Coupling_And_Cascading_Model"][:750] + " ..."),
            ("Zone C 切片采样（级联功能损失指标与仿真结果分析章节）", d["targeted_zones"]["Zone_C_Metrics_And_Simulation_Control"][:650] + " ..."),
            ("Zone D 切片采样（算例描述、讨论与文末局限性展望章节）", d["targeted_zones"]["Zone_D_Case_Social_And_Limitations"][-850:])
        ]
        for z_title, z_sample in zones_preview:
            p_z = doc.add_paragraph()
            p_z.paragraph_format.space_before = Pt(4)
            p_z.paragraph_format.space_after = Pt(2)
            rz1 = p_z.add_run(f"【{z_title}】：\n")
            rz1.font.name = "Times New Roman"
            rz1._element.rPr.rFonts.set(qn('w:eastAsia'), "微软雅黑")
            rz1.font.size = Pt(9.5)
            rz1.bold = True
            rz1.font.color.rgb = RGBColor(47, 85, 151)

            rz2 = p_z.add_run(z_sample.replace("\n", " "))
            rz2.font.name = "Times New Roman"
            rz2._element.rPr.rFonts.set(qn('w:eastAsia'), "宋体")
            rz2.font.size = Pt(9.0)
            rz2.font.color.rgb = RGBColor(64, 64, 64)

    docx_path = os.path.join(out_dir, "Step1_PDF章节树解析与四区靶向切片实验报告.docx")
    doc.save(docx_path)
    print("Saved Step 1 outputs to:", out_dir)

def main():
    ch2_dir = "/home/user/02_第2章_基于大语言模型文本数据挖掘的水电耦合系统前沿研究方向识别"
    pdf_dir = os.path.join(ch2_dir, "01_pdf_fulltext_corpus")
    out_dir = os.path.join(ch2_dir, "02_llm_pdf_mining_pipeline", "step1_slicing_output")

    pdf_files = sorted(f for f in os.listdir(pdf_dir) if f.endswith(".pdf"))
    parsed_docs = []
    for idx, fname in enumerate(pdf_files, start=1):
        fpath = os.path.join(pdf_dir, fname)
        doc_id = f"PDF_{idx:02d}"
        res = parse_pdf_structure(fpath, doc_id)
        parsed_docs.append(res)
        st = res["word_count_stats"]
        print(f"[{doc_id}] {fname[:45]}... | Pages: {res['total_pages']} | Raw: {st['raw_total_words']}w -> Kept: {st['kept_targeted_words']}w (Stripped: {st['stripped_noise_words']}w, -{st['noise_reduction_ratio_pct']}%)")

    generate_outputs(parsed_docs, out_dir)

if __name__ == "__main__":
    main()
