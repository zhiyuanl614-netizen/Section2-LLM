# Fine-grained evidence block QA

- Chunker version: `0.1.0`
- Config: target `180` words; maximum `240` words; overlap `0`.
- Boundary method: sentence-grouped within each section; unusually long sentences are split at clause punctuation, then at a word boundary if required.
- Offset basis: `char_start`/`char_end` are zero-based, end-exclusive Unicode-code-point indices into the exact Step 1 zone string, not raw PDF bytes or glyph positions. `source_excerpt` preserves the raw zone substring including inserted page tags for exact offset checking.
- `text` excludes inserted `[Page n]` tags and collapses layout whitespace; section/page metadata are preserved separately. No symbols were guessed or repaired.

## Per-document counts

| Doc ID | Evidence blocks | Zone A | Zone B | Zone C | Zone D | Unmapped glyph markers in blocks |
|---|---:|---:|---:|---:|---:|---:|
| B001-PDF-01 | 28 | 4 | 15 | 7 | 2 | 0 |
| B001-PDF-02 | 38 | 6 | 20 | 10 | 2 | 88 |
| B001-PDF-03 | 69 | 3 | 38 | 18 | 10 | 13 |
| B001-PDF-04 | 66 | 3 | 8 | 49 | 6 | 174 |
| B001-PDF-05 | 40 | 2 | 7 | 25 | 6 | 0 |

## QA checks

- Unique evidence IDs: `True`
- Offsets resolve to stored source excerpts: `True`
- Offsets are in bounds and non-overlapping within each source section: `True`
- Normalized source excerpt matches evidence `text`: `True`
- Page bounds/ranges and source PDF, Step 1 input, and Zone hashes are valid: `True`
- Evidence/retrieval-text hashes and section-heading matches are valid: `True`
- Stored word and character counts match the evidence text: `True`
- `retrieval_text` prepends the section heading to evidence `text`; source offsets address only the evidence substring, not the added heading.
- The 240-word cap applies to evidence `text`; `retrieval_text` additionally includes the section heading.
- No empty chunks: `True`
- All chunks are within the configured maximum: `True`
- Short chunks (<40 words): `4`; these are retained source units, not padded with guessed text.
- Heading/body audit notes: `13` total; empty parent/heading-only sections are logged as skipped, not fabricated.
- `text_sha256` and `retrieval_text_sha256` are recorded for each corresponding text field.

## Limitations and manual review

1. Step 1 did not retain paragraph bounding boxes or raw-PDF character offsets. These blocks are traceable to exact Step 1 zone strings, section headings, and extracted page tags/ranges; they are not raw-PDF character offsets.
2. PDF line breaks were reflowed to spaces. OCR/text extraction errors already present in the Zone input remain unchanged. `⟦PDF_GLYPH_U+XXXX⟧` markers are preserved and are not recovered symbols.
3. Chunk sizes are word-based because no target embedding tokenizer has been selected. Treat this as a versioned preprocessing default; tune it during retrieval pilot before indexing.
4. Zone A metadata labels are not evidence blocks; the abstract and retained contribution/intro text are included. Empty headings are omitted.

## Short-block review (<40 words)

| Evidence ID | Zone | Section | Pages | Words | Text sample |
|---|---|---|---|---:|---|
| B001-PDF-01-ZB-S10-3-2-C001 | Zone_B | 3.2. Analysis of the energy management method | 6 | 17 | According to the above simulation parameters, the MG integrating WSSs is tested. The results are as follows: |
| B001-PDF-03-ZB-S10-3-2-2-C001 | Zone_B | 3.2.2. Resourcefulness | 10 | 26 | Res (t): Rφ,ζ1 Res (t) = SPφ,ζ1(t) −SPφ,ζ1 ⟦PDF_GLYPH_U+0010⟧ 0 (t) = f Res(t): 0 (t) = F ⟦PDF_GLYPH_U+0010⟧ X Rζ1 Res(t |
| B001-PDF-05-ZB-S05-2-2-1-C002 | Zone_B | 2.2.1. Seismic fragility for pipelines of the WDS | 4 | 21 | A, B, and C are parameters for the standard repair rate function, with specific values referenced in Isoyama et al [30]. |
| B001-PDF-05-ZC-S13-3-2-C004 | Zone_C | 3.2. Seismic performance analysis for the PWS | 10 | 23 | However, the available power remains adequate for users with low energy demand, resulting in higher post- earthquake ene |

## Audit notes

| Doc ID | Zone | Issue | Heading / detail |
|---|---|---|---|
| B001-PDF-01 | Zone_C | empty_section_body_skipped | 3. Experimental results and discussion |
| B001-PDF-03 | Zone_B | empty_section_body_skipped | 2. Infrastructure Network Formalization |
| B001-PDF-03 | Zone_B | empty_section_body_skipped | 3. Infrastructure System Resilience Model |
| B001-PDF-03 | Zone_B | empty_section_body_skipped | 3.2. Three Features of Infrastructure System Resilience |
| B001-PDF-03 | Zone_B | empty_section_body_skipped | 4.2. First Repair Last Failures Strategy |
| B001-PDF-03 | Zone_D | empty_section_body_skipped | 5. Case Study |
| B001-PDF-03 | Zone_D | empty_section_body_skipped | 5.3. Test Case Disturbance—Flood Scenarios |
| B001-PDF-03 | Zone_D | empty_section_body_skipped | 6. Discussion |
| B001-PDF-03 | Zone_D | empty_section_body_skipped | 6.1. Hidden Impacts |
| B001-PDF-04 | Zone_C | empty_section_body_skipped | VI. IOR COMPUTATIONS |
| B001-PDF-04 | Zone_C | empty_section_body_skipped | VII. COMBINED CALCULATIONS |
| B001-PDF-04 | Zone_D | empty_section_body_skipped | VIII. APPLICATION EXAMPLE |
| B001-PDF-05 | Zone_C | empty_section_body_skipped | 2.3. Seismic performance analysis of individual system |
